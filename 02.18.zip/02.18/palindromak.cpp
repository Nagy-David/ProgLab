#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
 	
Palindr�m�k

�rjon programot, amely a standard bemenetrol soronk�nt egy
legfeljebb 29 karakter hossz�s�g� sztringet olvas be mindaddig,
am�g a beolvasott sztring nem palindrom sztring!
A palindrom sztringet arr�l lehet felismerni, hogy
el�lrol h�trafel� olvasva a karaktereinek a sorrendje
megegyezik a h�tulr�l elorefel� olvasottal. A program
az utols�k�nt beolvasott sztring kiv�tel�vel mindegyik
sztringet, valamint � tole egy sz�k�z karakterrel elv�lasztva
� az adott sztring hossz�t �rja ki a standard kimenetre!
P�lda bemenet

alma
eper retek cseresznye
ribizli
komor romok

let�lt�s sz�veges �llom�nyk�nt
A p�lda bemenethez tartoz� kimenet

    alma 4
    eper retek cseresznye 21
    ribizli 7
*/

int palindroma_e(char *s){
	int i;
	for(i=0; i<=strlen(s)/2; i++){
		if(s[i]!=s[strlen(s)-1-i]){
			return 0;
		}
	}
	return 1;
}

int main(){	
	char s[30];	
	while(1){
		gets(s);
		if(palindroma_e(s)){
			break;
		}
		printf("%s %d\n",s,strlen(s));	
	}
	return 0;
}




