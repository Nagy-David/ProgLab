#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int main(){
	
	char s[40];
	gets(s);
	
	printf("%s\n",strchr(s,' '));
	
	return 0;
}
