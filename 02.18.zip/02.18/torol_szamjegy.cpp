#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
//sz�mjegyek t�rl�se
int szamjegyekSzama(char *s){
	int i,db=0;
	for(i=0; i<strlen(s);i++){
		if(isdigit(s[i])){
			db++;
		}
	}
	return db;
}

char *torol2(char *s){
	char *uj = (char*)malloc(sizeof(char)*(szamjegyekSzama(s)+1) );
	int v = 0;
	int i;
	for(i=0; i<strlen(s);i++){
		if(!isdigit(s[i])){
			uj[v]=s[i];
			v++;
		}
	}
	uj[v]='\0';
	return uj;	
}


char* torol(char *s){
	char *uj = (char*)malloc(sizeof(char)*(strlen(s)+1) );
	int v = 0;
	int i;
	for(i=0; i<strlen(s);i++){
		if(!isdigit(s[i])){
			uj[v]=s[i];
			v++;
		}
	}
	uj[v]='\0';
	return uj;
} 

char *torol3(char *s){
	char *uj = (char*)malloc(sizeof(char)*1);
	int i,v = 0;
	for(i=0; i<strlen(s);i++){
		if(!isdigit(s[i])){
			uj[v++]=s[i];
			uj = (char *) realloc(uj, v+1);
		}
	}
	uj = (char *) realloc(uj, v+1);
	uj[v]='\0';
	return uj;	
}

char* torol4(char *s){
	char uj[strlen(s)+1];
	int v = 0;
	int i;
	for(i=0; i<strlen(s);i++){
		if(!isdigit(s[i])){
			uj[v]=s[i];
			v++;
		}
	}
	uj[v]='\0';
	return uj;
} 

int main(){
	
	char s[30];
	gets(s);
	char *t = torol4(s);
	puts(t);
	
	
	return 0;
}
