#include <ctype.h>
#include <string.h>
int is_c_identifier(char * s){
	int i;
	
	if(s[0]=='_' || s[strlen(s)-1]=='_' || strlen(s)==0){
		return 0;
	}
	
	for(i=0; i<strlen(s);i++){
		if( !(s[i]=='_' || islower(s[i]))  ){
			return 0;
		}  
		if(s[i]=='_' && s[i+1]=='_'){
			return 0;
		}
	}
	return 1;
}
