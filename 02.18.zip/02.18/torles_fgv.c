#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char* delete( char *s1, char *s2 ){
	int h = strlen(s1)-strlen(s2)+1;
	char *uj = (char*)malloc(sizeof(char)*h);
	int i,v = 0;
	char * tmp = strstr(s1,s2);
	int eleje = tmp-s1;
	int vege = eleje+strlen(s2);

	if(strlen(tmp)==0) {
		return s1;
	}
	
	for(i=0; i<eleje;i++){
		uj[v++]=s1[i];
	}
	for(i=vege; i<strlen(s1);i++){
		uj[v++]=s1[i];
	}
	uj[v]='\0';

	return uj;
}
