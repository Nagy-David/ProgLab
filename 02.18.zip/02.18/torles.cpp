#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
almamag ma
almamag mag
almamag maga
kerekerekerdo kereke
aaaaaa a
aaaaaa aaa
*/

char* torol( char *s1, char *s2 ){
	int h = strlen(s1)-strlen(s2)+1;
	char *uj = (char*)malloc(sizeof(char)*h);
	int i,v = 0;
	char * tmp = strstr(s1,s2);
	int eleje = strlen(s1)-strlen(tmp);
	int vege = eleje+strlen(s2);
	//printf("tmp: %s\n",tmp);
	if(tmp==NULL){
		return s1;
	}
	
	for(i=0; i<eleje;i++){
		uj[v++]=s1[i];
	}
	for(i=vege; i<strlen(s1);i++){
		uj[v++]=s1[i];
	}
	uj[v]='\0';
	
	//printf("%d\n",eleje);
	//printf("%d\n",eleje+strlen(s2));
	
	return uj;
}

int main()
{
char s1[ 30 ], s2[ 30 ];
char *torol( char *, char * );
while ( scanf( "%s %s", s1, s2 ) != EOF ){
    char *p = torol( s1, s2 );
    puts( p );
    free( p );
}
return EXIT_SUCCESS;
}
