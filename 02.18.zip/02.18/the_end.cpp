#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*

 	
THE END

�rjon programot, amely a standard bemenetrol soronk�nt egy-egy
legfeljebb 20 karakter hossz�s�g� sztringet olvas be mindaddig,
m�g a �THE END� sztringet nem olvassa! A program a beolvas�s
sorrendj�ben �rja a standard kimenetre a legal�bb 10 karakter
hossz�s�g�, sz�k�z karaktert nem tartalmaz� sztringeket

hehe, eszperente
cseresznye
meggy
elengedhetetlen
nem elengedhetetlen
ez sem kellene
elmerengtem
THE END
*/

int tartalmazSzokozt(char *s){ //char s[]
	int i;
	for(i=0; i<strlen(s);i++){
		if(s[i]==' '){
			return 1;
		}
	}
	return 0;
}


int main(){
	
	char s[21];
	while(1){
		
		gets(s);
		if(strcmp(s,"THE END")==0){
			break;
		}
		if(strlen(s)>= 10 && !tartalmazSzokozt(s)){
			printf("%s\n",s);
		}
	}
	
	
	
	return 0;
}
