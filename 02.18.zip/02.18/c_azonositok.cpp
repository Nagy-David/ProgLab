#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
/*
i
long_and_mnemonic_identifier
it_contains_1number
it_contains_CapitalLetters
dot.is_not_accepted
thisiscorrectalthoughthewordsarenotseparated
_
_foo
foo_
_foo_
foo_bar
foo__bar

let�lt�s sz�veges �llom�nyk�nt
A p�lda bemenethez tartoz� kimenet

YES
YES
NO
NO
NO
YES
NO
NO
NO
NO
NO
YES
NO
*/
int is_c_identifier(char * s){
	int i;
	
	if(s[0]=='_' || s[strlen(s)-1]=='_' || strlen(s)==0){
		return 0;
	}
	
	for(i=0; i<strlen(s);i++){
		if( !(s[i]=='_' || islower(s[i]))  ){
			return 0;
		}  
		if(s[i]=='_' && s[i+1]=='_'){
			return 0;
		}
	}
	return 1;
}


int main()
{
    char line[ 50 ];
    int is_c_identifier( char * );
    while ( gets( line ) != NULL )
    if ( is_c_identifier( line ) )
        puts( "YES" );
    else
        puts( "NO" );
    return EXIT_SUCCESS;
}
