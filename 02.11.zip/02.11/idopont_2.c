#include<stdio.h>
#include<stdlib.h>

int main(){	

	while(1){
		int ora1,perc1,ora2,perc2;
		scanf("%d",&ora1);
		if(ora1==-1){
			break;
		}
		scanf("%d %d %d",&perc1,&ora2,&perc2);
		int ido1 = ora1*60+perc1;
		int ido2 = ora2*60+perc2; 
		if(ido1 > ido2){
			printf(">\n");
		}
		else if(ido1 < ido2){
			printf("<\n");
		}
		else{
			printf("=\n");
		}
		
	}
	

	
	return 0;
}
