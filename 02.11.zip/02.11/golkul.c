#include<stdio.h>
#include<stdlib.h>

int main(){
	
	int x,y;
	int szum1=0, szum2=0;
	int max=INT_MIN;
	
	while(scanf("%d:%d",&x,&y)!=EOF){
		
		szum1+=x;
		szum2+=y;
		
		if(max<x-y){
			max=x-y;
		}
		
	}
	printf("%d:%d\n",szum1,szum2);
	printf("%d\n",max);
	
	
	return 0;
}
