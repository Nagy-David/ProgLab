#include<stdio.h>
#include<stdlib.h>

int main(){	

	int ora,perc;
	while(scanf("%d.%d",&ora,&perc)!=EOF){
		
		if(ora == 0){
			if(perc < 10){
				printf("12.0%dam\n",perc);
			}
			else{
				printf("12.%dam\n",perc);
			}
		}
		else if(ora > 0 && ora < 12 ){
			if(perc < 10){
				printf("%d.0%dam\n",ora,perc);
			}
			else{
				printf("%d.%dam\n",ora,perc);
			}
		}
		else if(ora > 12 && ora < 24){
			if(perc < 10){
				printf("%d.0%dpm\n",ora-12,perc);
			}
			else{
				printf("%d.%dpm\n",ora-12,perc);
			}
		}
		else{
			if(perc < 10){
				printf("12.0%dpm\n",perc);
			}
			else{
				printf("12.%dpm\n",perc);
			}
		}
		
	}


	return 0;
}
