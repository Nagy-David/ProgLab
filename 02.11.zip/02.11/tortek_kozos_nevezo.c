#include<stdio.h>
#include<stdlib.h>

int lnko(int a, int b){	
	int lnko = a<b?a:b;	
	while(1){
		if(a%lnko == 0 && b%lnko == 0 ){
			return lnko;
		}
		lnko--;
	}
}



int main(){	

	int a,b,c,d;
	while(1){
		
		scanf("%d %d %d %d",&a,&b,&c,&d);
		
		if(a==0 && b==0 && c==0 && d==0){
			break;
		}
		
		int kn = (b*d)/lnko(b,d); //lkkt
		/*
		3 15 --> (60/15)*3 = 12 
		2 20 --> (60/20)*2 = 6
		
		kn = 60
		*/
		//printf("kn: %d\n",kn);
		a *= (kn/b);
		c *= (kn/d);
		
		if(a > c){
			printf(">\n");
		}
		else if(a < c){
			printf("<\n");
		}
		else{
			printf("=\n");
		}
		
		
	}
	
	return 0;
	
}
