#include<stdio.h>
#include<stdlib.h>
int main(){
	int n;
	int s = 1;
	while(1){		
		scanf("%d",&n);		
		if(n==0){
			break;
		}		
		int i,m;
		int db_p=0;
		int db_n=0;
		for(i=0; i<n;i++){
			scanf("%d",&m);
			if(m>0){
				db_p++;
			}
			if(m<0){
				db_n++;
			}
		}
		if(db_p>db_n){
			printf("%d\n",s);
		}
		
		s++;
		
	}	
	return 0;
}
