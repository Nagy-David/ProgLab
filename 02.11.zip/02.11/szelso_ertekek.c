#include<stdio.h>
#include<stdlib.h>

int main(){	

	int n;
	while(1){		
		scanf("%d",&n);		
		if(n==0){
			break;
		}		
		int tomb[n];
		int i;
		for(i=0; i<n;i++){
			scanf("%d",&tomb[i]);
		}
		
		if(tomb[0]==tomb[n-1]){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}		
	}


	return 0;
}
