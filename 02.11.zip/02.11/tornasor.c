#include<stdio.h>
#include<stdlib.h>
int main(){
	int n;
	while(1){		
		scanf("%d",&n);		
		if(n==0){
			break;
		}		
		int i,m;
		int min=300;
		int max=-1;
		for(i=0; i<n;i++){
			scanf("%d",&m);
			if(m>max){
				max=m;
			}
			if(m<min){
				min=m;
			}
		}
		printf("%d %d\n",min,max);
	}	
	return 0;
}
