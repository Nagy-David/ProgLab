#include<stdio.h>
#include<stdlib.h>

int main(){	

	int a,b,c,d;
	while(1){
		
		scanf("%d %d %d %d",&a,&b,&c,&d);
		
		if(a==0 && b==0 && c==0 && d==0){
			break;
		}
		
		double tort1 = (double)a/(double)b;
		double tort2 = (double)c/(double)d;
		
		//printf("tort1: %lf\n",tort1);
		//printf("tort2: %lf\n",tort2);
		if(tort1 > tort2){
			printf(">\n");
		}
		else if(tort1 < tort2){
			printf("<\n");
		}
		else{
			printf("=\n");
		}
		
	}
	
	return 0;
	
}
