#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
	
Besz�mol�
Az egyik tant�rgyb�l a hallgat�knak h�trol h�tre be kell sz�molniuk az elsaj�t�tott tananyagb�l. Na persze nem minden h�ten mindenkinek � hiszen arra nem is lenne mindig ido �, hanem egy elore meghat�rozott �temez�s szerint. �rjon egy programot, amely a standard bemenetrol �llom�nyv�gjelig hallgat�k adatait olvassa be soronk�nt, �sszesen legfeljebb 20-at! Egy sor fel�p�t�se a k�vetkezo:

n�v/�temez�s

A n�v egy legfeljebb 50 karakter hossz�, csak angol betuket, k�tojelet (m�nuszjelet) �s
sz�k�z karaktert tartalmaz� egyedi sztring. Az �temez�s egy pontosan 15 karakter hossz�s�g�,
kiz�r�lag 0 �s 1 sz�mjegyekbol �ll� sztring, ahol az i-edik helyen �ll� 1-es sz�mjegy azt jelzi,
hogy az i-edik h�ten a hallgat�nak besz�mol�ja lesz, m�g a 0-s sz�mjegy azt, hogy nem.
Az adatokat a sorban egy-egy oszt�sjel (perjel) karakter v�lasztja el egym�st�l.

A program az elso besz�mol� idopontja szerint rendezze n�vekvo sorrendbe az adatokat,
azaz elore ker�ljenek azok a hallgat�k, akiknek a legkor�bban van az elso besz�mol�juk!
Ha t�bb hallgat�nak is azonos h�tre esne a legelso besz�mol�ja, akkor oket a nev�k szerint
lexikografikusan n�vekvo sorrendbe tegye a program, majd �rja a standard kimenetre a hallgat�k
neveinek ily m�don rendezett list�j�t!

P�lda bemenet
Teszt Elek/001001001001001
Meno Jeno/110110110110110
Bena Bela/101010101010101
Teszt Elek2/000001001001001
Meno Jeno2/010110110110110
Bena Bela2/001010101010101


A p�lda bemenethez tartoz� kimenet
Bena Bela
Meno Jeno
Teszt Elek
*/

typedef struct hallgato{
	char nev[51];
	int legelso_beszamolo;
}hallgato;

void kiir(hallgato h[], int meret){
	int i;
	for(i=0; i<meret;i++){
		//printf("Nev: %s, elso beszamolo napja: %d\n",h[i].nev,h[i].legelso_beszamolo);
		printf("%s\n",h[i].nev);
	}
}


//> rel�ci�
//kimenet: +1 ha h1 > h2 
// -1 ha h1 < h2
//0 ha h1 == h2
int hasonlit(hallgato h1, hallgato h2){
	if(h1.legelso_beszamolo > h2.legelso_beszamolo){
		return 1;
	}
	else if(h1.legelso_beszamolo < h2.legelso_beszamolo){
		return -1;
	}
	else{
		return strcmp(h1.nev,h2.nev);
	}
	
}

void buborekos_rendezes(hallgato h[], int meret){
	int i,j;
	for(i=meret-1; i>=1; i--){
		for(j=0; j<i;j++){
			if(hasonlit(h[j],h[j+1]) >= 1){
				hallgato seged = h[j];
				h[j] = h[j+1];
				h[j+1] = seged;
			}
		}
	}
}


int main(){
	
	char sor[67];
	hallgato h[10000];
	int db=0;
	
	while(gets(sor)!=NULL){
		char *token = strtok(sor,"/");
		strcpy(h[db].nev,token);
		token = strtok(NULL,"/");
		int i;
		for(i=0; i<strlen(token);i++){
			if(token[i]=='1'){
				h[db].legelso_beszamolo = i;
				break;
			}
		}
		db++;
	}
	
	buborekos_rendezes(h,db);
	kiir(h,db);
	
	return 0;
}






