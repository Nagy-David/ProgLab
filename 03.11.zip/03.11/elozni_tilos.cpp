/*
	
Elozni tilos!
�rjon egy olyan C f�ggv�nyt, amely param�terk�nt megkap egy sztringet, tov�bb� k�t karaktert!
A f�ggv�ny d�ntse el, hogy az elso karakter �sszes elofordul�sa megelozi-e a m�sodik karakter
�sszes elofordul�s�t a sztringben, �s igaz �rt�kkel t�rjen vissza, ha �gy lenne, hamissal,
ha nem! Ha a megadott k�t karakter k�z�l valamelyik nem szerepelne a sztringben,
akkor a f�ggv�ny igaz �rt�ket adjon vissza! A f�ggv�ny specifik�ci�ja a k�vetkezo:

abrakadabra
a b
abrakadabra
k d
abrakadabra
d k
abrakadabra
c a
abrakadabra
a c
abrakadabra
c e

A p�lda bemenethez tartoz� kimenet
NO
YES
NO
YES
YES
YES

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int all_before(char *s , char c1, char c2){
	int i;
	for(i=0; i<strlen(s);i++){
		if(s[i]==c2){
			int j;
			for(j=i+1; j<strlen(s);j++){
				if(s[j]==c1){
					return 0;
				}
			}
			return 1;
		}
	}
}

int main()
{
  char line[200];
  int all_before(char *, char, char);
  while (gets(line) != NULL)
  {
    char a, b, str[200];
    int res;
    strcpy(str, line);
    gets(line);
    a = line[0];
    b = line[2];
    res = all_before(str, a, b);
    puts(res ? "YES" : "NO");
  }
  return EXIT_SUCCESS;
}
