int all_before(char *s , char c1, char c2){
	int i;
	for(i=0; i<strlen(s);i++){
		if(s[i]==c2){
			int j;
			for(j=i+1; j<strlen(s);j++){
				if(s[j]==c1){
					return 0;
				}
			}
			return 1;
		}
	}
}
