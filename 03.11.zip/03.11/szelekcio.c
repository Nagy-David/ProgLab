#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
/*
Szelekci�
�rjon programot, amely eg�sz sz�mok egy elore megadott list�j�b�l elt�nteti a legkisebb �rt�kueket, a megmaradtakat pedig ki�rja a standard kimenetre!

A bemenet elso sora pontosan egy darab pozit�v eg�sz sz�mot (N) tartalmaz, ami a feldolgozand� tesztesetek sz�m�t jelzi. A k�vetkezo N sor mindegyik�ben eg�sz sz�mok szerepelnek. Minden sor elso sz�ma (K, ahol 1 = K = 10) azt �rulja el, hogy h�ny tov�bbi sz�m tal�lhat� a sorban. Programj�nak ezek k�z�l a sz�mok k�z�l kell meghat�roznia a legkisebbet, majd ezen �rt�k kiv�tel�vel az �sszes t�bbit az eredeti sorrendben, egy-egy sz�k�z karakterrel elv�lasztva kell a standard kimenetre �rnia! Figyeljen r�, hogy a sz�k�z karaktert csak a ki�rt sz�mok egym�st�l val� elv�laszt�s�ra haszn�lja! Ha egy tesztesetben csupa egyforma sz�m szerepelt volna, akkor a neki megfelelo kimenet egy �res sor legyen!

P�lda bemenet
4
4 7 5 8 6
2 5 5
3 9 8 7
5 2 3 4 5 6
let�lt�s sz�veges �llom�nyk�nt
A p�lda bemenethez tartoz� kimenet
7 8 6

9 8
3 4 5 6

*/

int main(){
	
	int i,j,n,m;
	scanf("%d",&n);
	for(i=0; i<n;i++){
		
		scanf("%d",&m);
		int tomb[m];
		int min=INT_MAX;	
		for(j=0; j<m;j++){
			scanf("%d",&tomb[j]);
			if(tomb[j]<min){
				min=tomb[j];
			}
		}
		int db = 0;
		for(j=0; j<m;j++){
			
			if(tomb[j]!=min){
				if(db == 0){
					printf("%d",tomb[j]);
				}
				else{
					printf(" %d",tomb[j]);
				}
				db++;
			}		
		}
		printf("\n");
	}

	return 0;
}



