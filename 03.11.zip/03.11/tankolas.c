#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
Tankol�s
�rjon egy programot, amely a standard bemenetrol �llom�nyv�gjelig aut�k �zemanyag-fogyaszt�si adatait olvassa be soronk�nt, �sszesen legfeljebb 20-at! Egy sor fel�p�t�se a k�vetkezo:

aut�_rendsz�ma/tankol�sok

Az aut�_rendsz�ma egy legfeljebb 7 karakter hossz�, csak angol betuket, sz�mjegyeket �s k�tojelet (m�nuszjelet) tartalmaz� egyedi sztring. A tankol�sok egy pontosan 12 karakter hossz�s�g�, kiz�r�lag 0 �s 1 karakterekbol �ll� sztring, ahol az i-edik helyen �ll� karakter azt jelzi, hogy az �v i-edik h�napj�ban v�s�roltak-e �zemanyagot az aut�ba: 1-es �rt�k eset�n t�rt�nt tankol�s, 0-s eset�n nem t�rt�nt tankol�s az adott h�napban. Az adatokat a sorban egy-egy oszt�sjel (perjel) karakter v�lasztja el egym�st�l.

A program az aut�k adatait a tankol�sok sz�ma szerint rendezze cs�kkeno sorrendbe, elore �ll�tva azokat az aut�kat, amelyeket a legt�bb h�napban tankoltak meg! Ha t�bb olyan aut� is lenne, amelyet egyform�n sok h�napban tankoltak meg, akkor oket a rendsz�muk szerint lexikografikusan n�vekvo sorrendbe tegye a program, majd v�g�l �rja a standard kimenetre azon aut�k rendsz�mainak ily m�don rendezett list�j�t, amelyeket az �v legal�bb 3 h�napj�ban megtankoltak!

P�lda bemenet
XYZ987/101010101010
ABC123/010101010101
BBB888/111111000000
let�lt�s sz�veges �llom�nyk�nt
A p�lda bemenethez tartoz� kimenet
ABC123
BBB888
XYZ987

*/


typedef struct kocsi{
	char rendszam[8];
	int tankolasok;
}kocsi;

void kiir(kocsi k[], int meret){
	int i;
	for(i=0; i<meret;i++){
		if (k[i].tankolasok >= 3){
			printf("%s\n",k[i].rendszam);	
		}
	}
}
int hasonlit(const void *a, const void *b){	
	kocsi *k1 = (kocsi*)a;
	kocsi *k2 = (kocsi*)b;	
	if(k1->tankolasok > k2->tankolasok){
		return -1;
	}
	else if(k1->tankolasok < k2->tankolasok){
		return 1;
	}
	else{
		return strcmp(k1->rendszam,k2->rendszam);
	}	
}
int main(){	
	char sor[21];
	kocsi k[20];
	int db=0;	
	while(gets(sor)!=NULL){
		char *token = strtok(sor,"/");
		strcpy(k[db].rendszam,token);
		token = strtok(NULL,"/");
		int i;
		k[db].tankolasok = 0;
		for(i=0; i<strlen(token);i++){
			if(token[i]=='1'){
				k[db].tankolasok++;
			}
		}
		db++;
	}	
	qsort(k,db,sizeof(kocsi),hasonlit);
	kiir(k,db);
	return 0;
}


