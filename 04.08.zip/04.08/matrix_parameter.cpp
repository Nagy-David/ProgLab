#include<stdio.h>
#include<stdlib.h>
#include<time.h>
/*
void kiir( int matrix[][3], int n ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<3;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
	
}
*/

void feltolt(int **matrix, int n, int m){
	srand(time(NULL));
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			matrix[i][j]=rand()%9+1;
		}
	}
}


void kiir( int **matrix, int n, int m ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
}

/*
1. feladat: 
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trixban
p�ros sz�mok darabsz�m�t adja vissza.

2. feladat:
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trixr�l eld�nti, hogy
minden eleme p�ros-e

3. feladat:
�rjon elj�r�st, mely a bemenetek�nt kapott m�trix f��tl�j�t �rja ki.

4. feladat:
�rjon elj�r�st mely a bemenetek�nt kapott m�trix oszloponk�nti
�sszegeit ki�rja pontosan egy sz�k�z karakterrel elv�lasztva.
Be:
2 3 4
1 2 4
0 1 1
Ki: 3 6 9

5. feladat:
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trix eset�n megvizsg�lja, hogy
van-e olyan sora a m�trixnak, mely csupa p�ros sz�mb�l �ll.
Ha van ilyen sora, akkor a program �rja a YES sz�t a kimenetre, ha nincs akkor a
NO sz�t.
Be:
2 3 4
1 2 4
0 2 2
Ki: YES

*/



int main(){
	
	int **matrix;
	int i;
	matrix = (int**)malloc(sizeof(int*)*3); //sor
	for(i=0; i<3;i++){
		matrix[i]=(int*)malloc(sizeof(int)*3); //oszlop
	}
	
	feltolt(matrix,3,3);
	kiir(matrix,3,3);
	
	return 0;
}
