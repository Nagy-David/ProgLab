/*
5. feladat:
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trix eset�n megvizsg�lja, hogy
van-e olyan sora a m�trixnak, mely csupa p�ros sz�mb�l �ll.
Ha van ilyen sora, akkor a program �rja a YES sz�t a kimenetre, ha nincs akkor a
NO sz�t.
Be:
2 3 4
1 2 4
0 2 2
Ki: YES

*/


#include<stdio.h>
#include<stdlib.h>
#include<time.h>


void feltolt(int **matrix, int n, int m){
	srand(time(NULL));
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			matrix[i][j]=rand()%9+1;
		}
	}
}


void kiir( int **matrix, int n, int m ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
}
//t�mb minden eleme paros-e
int mind_paros(int tomb[], int meret){
	int i;
	for(i=0; i<meret;i++){
		if(tomb[i]%2!=0){
			return 0;
		}
	}
	return 1;
}
//soronk�nt megy �s megn�zi, hogy van-e olyan sor (t�mb) ahol minden elem paros.
int sor_mind_paros( int **matrix, int n, int m ){
	int i;
	for(i=0; i<n;i++){
		if(mind_paros(matrix[i],m)){
			return 1;
		}
	}
	return 0;
}


int main(){
	
	int **matrix;
	int i;
	matrix = (int**)malloc(sizeof(int*)*3); //sor
	for(i=0; i<3;i++){
		matrix[i]=(int*)malloc(sizeof(int)*3); //oszlop
	}
	
	feltolt(matrix,3,3);
	kiir(matrix,3,3);
	if(sor_mind_paros(matrix,3,3)){
		printf("Van olyan sor, ahol minden elem paros!\n");
	}
	else{
		printf("Nincs olyan sor, ahol minden elem paros!\n");	
	}
	
	return 0;
}
