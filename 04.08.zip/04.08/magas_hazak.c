#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
Magas szintu programoz�si nyelvek 1, 2017. janu�r 4., Sz10 ZH
	
Magas h�zak

�rjon programot, amely a standard bemenetrol az angol �b�c� nagybetuit 
tartalmaz� sztringeket olvas 
be �llom�nyv�gjelig, soronk�nt egyet-egyet! 
A sztring egy utca h�zait �rja le, az 'A' betu a legkisebb 
h�zat, a 'Z' a legnagyobbat, a t�bbi betu pedig ar�nyosan 
magas h�zakat e tartom�ny k�t v�gpontja k�z�tt. 
Az utc�ban nincs k�t egyform�n magas h�z.

A programja hat�rozza meg �s �rja utc�nk�nt a standard kimenetre, 
hogy az utca egyik v�g�rol az utca m�sik 
v�ge fel� tekintve h�ny darab h�z l�that�, figyelembe v�ve, hogy a 
magas h�zak eltakarj�k a m�g�tt�k sorakoz� kisebbeket!
P�lda bemenet

ABCDE
EDCBA
CABED

A p�lda bemenethez tartoz� kimenet

5
1
2

*/
int main(){
	
	char sor[26];
	while(gets(sor)!=NULL){
		int i,db=1;
		char max=sor[0];
		for(i=1; i<strlen(sor);i++){
			if(sor[i]>max){
				max=sor[i];
				db++;
			}
		}
		printf("%d\n",db);
	}
	return 0;
}













