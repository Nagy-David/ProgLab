#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
Magas szintu programoz�si nyelvek 1, 2017. janu�r 4., Sz10 ZH 
 	
Hossz� zenesz�mok

�rjon programot, amely a standard bemenetrol legend�s zenekarok 
egy-egy felejthetetlen album�nak zenesz�mair�l olvas be adatokat 
(az albumon val� elhelyezked�s fizikai sorrendj�ben), maxim�lisan 
legfeljebb 50 darabot:

kezdes_perc;kezdes_masodperc;c�m

A kezdes_perc �s kezdes_masodperc adatok a sz�mok kezd�si 
adatait mutatj�k. A zenesz�mok c�me egy legal�bb 1, legfeljebb 
100 karaktert tartalmaz� sztring. Az album elso sz�m�nak 
kezd�si idopontja 0.00, a t�bbiek kezd�se ehhez az idoponthoz 
van viszony�tva. A programj�nak a leghosszabb lej�tsz�si idovel 
rendelkezo zenesz�mok c�meit kell a standard kimenetre �rnia, 
soronk�nt egyet-egyet, lexikografikusan n�vekvo sorrendben. 
Az utols� sor egy �lrekord, amelynek a c�m mezoje az �res 
sztringet tartalmazza, �s csak az�rt szerepel a felsorol�sban, 
hogy meg lehessen �llap�tani az utols� zenesz�m lej�tsz�si idej�t.
P�lda bemenet

0;0;Madame Pompadour
3;58;Uj harci dal
6;55;Angyali vallomas
10;34;Neurovizio
14;21;25 este New Yorkban
17;52;Szepek szepe balladaja
21;41;Allj, vagy lovok!
24;58;Szivedben elnek
29;3;A lany korbejar
32;27;Sorsvonat
36;13;Emelet-indulo
39;25;A szerelem el
43;41;


A p�lda bemenethez tartoz� kimenet

A szerelem el

*/
typedef struct zene{
	char cim[101];
	int hossz;
	int perc;
	int mp;
}zene;

int hasonlit(const void *a, const void*b){
	zene *z1 = (zene*)a;
	zene *z2 = (zene*)b;
	
	return strcmp(z1->cim,z2->cim);
}

int main(){
	
	char sor[110];
	zene z[50];
	int db=0;
	
	while(gets(sor)!=NULL){	
		z[db].perc = atoi(strtok(sor,";"));
		z[db].mp = atoi(strtok(NULL,";"));
		
		char *token = strtok(NULL,";");
		
		if(token){ //if(token!=NULL)
			strcpy(z[db].cim,token);	
		}
		
		else{
			strcpy(z[db].cim,"END");
		}
		
		db++;
	}
	int i;
	for(i=1; i<db;i++){
		z[i-1].hossz = (z[i].perc*60+z[i].mp)-(z[i-1].perc*60+z[i-1].mp);
	}
	qsort(z,db-1,sizeof(zene),hasonlit);
	
	int max = z[0].hossz;
	
	for(i=1; i<db-1;i++){
		if(z[i].hossz > max){
			max=z[i].hossz;
		}
	}
	
	for(i=0; i<db;i++){
		if(z[i].hossz == max){
			printf("%s: %d\n",z[i].cim,z[i].hossz);
		}	
	}
	
	
	return 0;
}





