#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
 
Magas szintu programoz�si nyelvek 1, 2016. m�jus 23., H16 ZH 
 	
Deklar�ci�

�rjon programot, amely eld�nti, hogy egy C deklar�ci�s utas�t�sban deklar�lt 
v�ltoz�k nevei lexikografikusan n�vekvo sorrendben k�vetik-e egym�st!
A bemenet t�bb tesztesetet tartalmaz. Minden teszteset egyetlen sorb�l �ll, 
egy deklar�ci�s utas�t�sb�l, amelynek alakja a k�vetkezo:
t�pus v�ltoz�n�v[,v�ltoz�n�v]�;
A deklar�ci�ban az elso v�ltoz�nevet a t�pust�l pontosan egy ' ' (sz�k�z) 
karakter, m�g a v�ltoz�neveket egym�st�l mindig egy ',' (vesszo) karakter 
v�lasztja el. A deklar�ci�s utas�t�st egy ';' (pontosvesszo) karakter z�rja. 
Felt�telezheto, hogy a deklar�ci�s utas�t�sok hossza nem haladja meg az 1000 
karaktert.
A program minden tesztesetre �rjon a standard kimenetre egy �YES� �zenetet, 
ha a deklar�ci�ban a v�ltoz�nevek lexikografikusan n�vekvo sorrendben k�vetik egym�st, �s egy �NO�-t, ha nem!
P�lda bemenet

int a,c,e;
float e,d,c,b,a;
double alma,banan,citrom,dio,eper;

let�lt�s sz�veges �llom�nyk�nt
A p�lda bemenethez tartoz� kimenet

YES
NO
YES
*/

int main(){
	
	char sor[1001];
	while(gets(sor)!=NULL){
		
		char *token = strtok(sor," ");
		token = strtok(NULL," "); //v�ltoz�k
		token[strlen(token)-1]='\0'; //; lev�g�sa
		
		char tomb[1000][1000];
		int db = 0;
		char *token2 = strtok(token,",");
		while(token2!=NULL){
			strcpy(tomb[db++],token2);
			token2 = strtok(NULL,",");
		}
		int i;
		/*
		printf("Szavak:\n");
		for(i=0; i<db;i++){
			printf("%s\n",tomb[i]);
		}
		*/
		int flag = 1;
		for(i=0; i<db-1;i++){
			if(strcmp(tomb[i],tomb[i+1]) == 1){
				flag = 0;
				break;
			} 
		}
		if(flag){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
		
		
	}
	
	return 0;
}




