#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
Olvassunk be legfeljebb 20 darab maximum 30 hossz�s�g� sz�t a standard bemenetr�l
EOF v�gjelig. �rjuk ki a szavakat beolvas�sukkal ellent�tes sorrendben.
*/

int main(){
	
	char tomb[20][31];
	int db = 0; //a beolvasott szavak darabsz�ma
	
	char sor[31];
	
	while(gets(sor)!=NULL){
		strcpy(tomb[db++],sor);
		//db++; k�l�n utas�t�sban is j�.
	}
	
	//while(scanf("%s",tomb[db++])!=EOF);
	
	
	int i;
	printf("Visszafele:\n");
	for(i=db-1; i>=0; i--){
		printf("%s\n",tomb[i]);
	}
	
	
	return 0;
}
