#include<stdio.h>
#include<stdlib.h>
#include<time.h>

/*
1. feladat: 
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trixban
p�ros sz�mok darabsz�m�t adja vissza.
*/

void feltolt(int **matrix, int n, int m){
	srand(time(NULL));
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			matrix[i][j]=rand()%9+1;
		}
	}
}


void kiir( int **matrix, int n, int m ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
}

int paros_db( int **matrix, int n, int m ){
	int i,j;
	int db = 0;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			if(matrix[i][j]%2==0){
				db++;
			}
		}
	}
	return db;
}


int main(){
	
	int **matrix;
	int i;
	matrix = (int**)malloc(sizeof(int*)*3); //sor
	for(i=0; i<3;i++){
		matrix[i]=(int*)malloc(sizeof(int)*3); //oszlop
	}
	
	feltolt(matrix,3,3);
	kiir(matrix,3,3);
	printf("Paros szamok db: %d\n",paros_db(matrix,3,3));
	
	return 0;
}
