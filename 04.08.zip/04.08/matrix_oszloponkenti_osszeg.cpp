/*
4. feladat:
�rjon elj�r�st mely a bemenetek�nt kapott m�trix oszloponk�nti
�sszegeit ki�rja pontosan egy sz�k�z karakterrel elv�lasztva.
Be:
2 3 4
1 2 4
0 1 1
Ki: 3 6 9
*/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>


void feltolt(int **matrix, int n, int m){
	srand(time(NULL));
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			matrix[i][j]=rand()%9+1;
		}
	}
}


void kiir( int **matrix, int n, int m ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
}

void osszeg( int **matrix, int n, int m ){
	int i,j;
	printf("\nOszloponkenti osszeg:\n");
	for(j=0; j<n; j++){
		int szum = 0;
		for(i=0; i<m;i++){
			szum+=matrix[i][j];
		}
		printf("%d ",szum);
	}	

}


int main(){
	
	int **matrix;
	int i;
	matrix = (int**)malloc(sizeof(int*)*3); //sor
	for(i=0; i<3;i++){
		matrix[i]=(int*)malloc(sizeof(int)*3); //oszlop
	}
	
	feltolt(matrix,3,3);
	kiir(matrix,3,3);
	osszeg(matrix,3,3);
	
	return 0;
}

