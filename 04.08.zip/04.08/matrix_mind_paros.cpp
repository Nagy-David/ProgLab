/*
2. feladat:
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trixr�l eld�nti, hogy
minden eleme p�ros-e
*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h>

/*
1. feladat: 
�rjon f�ggv�nyt, mely a bemenetek�nt kapott m�trixban
p�ros sz�mok darabsz�m�t adja vissza.
*/

void feltolt(int **matrix, int n, int m){
	srand(time(NULL));
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			matrix[i][j]=rand()%9+1;
		}
	}
}


void kiir( int **matrix, int n, int m ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
}

int mind_paros( int **matrix, int n, int m ){
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			if(matrix[i][j]%2!=0){
				return 0;
			}
		}
	}
	return 1;
}


int main(){
	
	int **matrix;
	int i;
	matrix = (int**)malloc(sizeof(int*)*3); //sor
	for(i=0; i<3;i++){
		matrix[i]=(int*)malloc(sizeof(int)*3); //oszlop
	}
	
	feltolt(matrix,3,3);
	kiir(matrix,3,3);
	if(mind_paros(matrix,3,3)){
		printf("A matrix minden eleme paros!\n");
	}
	else{
		printf("A matrix NEM minden eleme paros!\n");	
	}
	
	return 0;
}
