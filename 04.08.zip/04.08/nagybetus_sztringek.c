/*
Magas szintu programoz�si nyelvek 1, 2016. m�jus 18., Sz18 ZH
 	
NAGYBETUS sztringek

�rja meg a myheader.h �llom�nyban deklar�lt foo() f�ggv�nyt, amely param�terk�nt 
megkapja egy sztringeket tartalmaz� t�mb kezdoc�m�t �s elemsz�m�t! A f�ggv�ny 
hat�rozza meg, hogy h�ny olyan sztring van a t�mbben, amelyikben kiz�r�lag az 
angol �b�c� nagybetui fordulnak elo (n darab), majd hozzon l�tre egy �j, n+1 
elemu t�mb�t, amelynek elso n eleme az az n darab mutat� legyen az eredeti t�mbbeli 
elhelyezked�s�k sorrendj�ben, amelyek az eredeti t�mb csupa nagybetukbol �ll� 
sztringjeit c�mzik! Az �j t�mb (n+1)-edik eleme egy NULL mutat� legyen! 
A f�ggv�ny visszat�r�si �rt�ke az �jonnan l�trehozott mutat�t�mb kezdoc�me legyen!


*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int nagybetus(char *s){
	int i;
	for(i=0; i<strlen(s);i++){
		if(!isupper(s[i])){
			return 0;
		}
	}
	return 1;
}

int nagybetus_db(char *tomb[], int meret){
	int i;
	int db=0;
	for(i=0; i<meret;i++){
		if(nagybetus(tomb[i])){
			db++;
		}
	}
	return db;
}

char** foo(char*tomb[], int meret){
	int uj_meret = nagybetus_db(tomb,meret);
	//helyfoglal�s
	char **uj = (char**)malloc(sizeof(char*)*(uj_meret+1) );
	int i;
	for(i=0; i<uj_meret;i++){
		uj[i]=(char*)malloc(sizeof(char)*1000);
	}
	//ha az eredeti tomb egy eleme csak nagybet�b�l �ll, 
	//akkor azt �tm�solom az uj t�mbbe.
	int db = 0;
	for(i=0; i<meret;i++){
		if(nagybetus(tomb[i])){
			strcpy(uj[db++],tomb[i]);
		}
	}
	uj[db++]=NULL; //az utols� eleme pedig a NULL lesz.
	return uj;
}

int main()
{
    char *t[] = {"ALMA", "szilva", "KORTE", "ePer", "Meggy", "CSERESZNYE"};
    char **result = foo(t, sizeof(t) / sizeof(char *));
    char **tmp;
    for (tmp = result; *tmp; ++tmp)
        	printf("%s\n", *tmp);
    free(result);
    return EXIT_SUCCESS;
}
