/*
3. feladat:
�rjon elj�r�st, mely a bemenetek�nt kapott m�trix f��tl�j�t �rja ki.
*/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>


void feltolt(int **matrix, int n, int m){
	srand(time(NULL));
	int i,j;
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			matrix[i][j]=rand()%9+1;
		}
	}
}


void kiir( int **matrix, int n, int m ){
	int i,j;
	printf("Sorfolytonos:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
}

void foatlo( int **matrix, int n, int m ){
	int i,j;
	printf("\nFoatlo:\n");
	for(i=0; i<n; i++){
		for(j=0; j<m;j++){
			if(i==j){
				printf("%d ",matrix[i][j]);
			}
		}
	}	
	/*
	for(i=0; i<n;i++)
		printf("%d ",matrix[i][i]);
	*/	
}


int main(){
	
	int **matrix;
	int i;
	matrix = (int**)malloc(sizeof(int*)*3); //sor
	for(i=0; i<3;i++){
		matrix[i]=(int*)malloc(sizeof(int)*3); //oszlop
	}
	
	feltolt(matrix,3,3);
	kiir(matrix,3,3);
	foatlo(matrix,3,3);
	
	return 0;
}

