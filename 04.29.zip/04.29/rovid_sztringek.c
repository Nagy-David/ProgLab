#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
Magas szintu programoz�si nyelvek 1, 2016. m�jus 18., Sz10 ZH
	
R�vid sztringek

�rja meg a myheader.h �llom�nyban deklar�lt foo() f�ggv�nyt, 
amely param�terk�nt megkapja egy sztringeket tartalmaz� t�mb 
kezdoc�m�t �s elemsz�m�t! A f�ggv�ny hat�rozza meg a t�mb legr�videbb 
sztringj�nek a hossz�t, sz�molja meg, hogy h�ny ilyen hossz�s�g� 
sztring van a t�mbben (n darab), majd hozzon l�tre egy �j, n+1 
elemu t�mb�t, amelynek elso n eleme az az n darab mutat� legyen az 
eredeti t�mbbeli elhelyezked�s�k sorrendj�ben, amelyek az eredeti 
t�mb legr�videbb sztringjeit c�mzik! Az �j t�mb (n+1)-edik eleme 
egy NULL mutat� legyen! A f�ggv�ny visszat�r�si �rt�ke az �jonnan 
l�trehozott mutat�t�mb kezdoc�me legyen!
*/
int legrovidebb_hossz(char **tomb, int meret){
	int min=strlen(tomb[0]);
	int i;
	for(i=0; i<meret;i++){
		if(strlen(tomb[i])<min){
			min=strlen(tomb[i]);
		}
	}
	return min;
}

int legrovidebb_hossz_db(char **tomb, int meret){
	int min=legrovidebb_hossz(tomb,meret);
	int i,db=0;
	for(i=0; i<meret;i++){
		if(strlen(tomb[i])==min){
			db++;
		}
	}
	return db;
}

char **foo(char **tomb, int meret){
	int min= legrovidebb_hossz(tomb,meret);
	int db = legrovidebb_hossz_db(tomb,meret);
	int i,v=0;
	char **uj = (char**)malloc(sizeof(char*)*(db+1));
	for(i=0; i<db+1;i++){
		uj[i]=(char*)malloc(sizeof(char)*(min+1));
	}
	for(i=0; i<meret;i++){
		if(strlen(tomb[i])==min){
			strcpy(uj[v++],tomb[i]);
		}
	}
	uj[v++]=NULL;
	return uj;	
}


int main()
{
    char *t[] = {"alma", "szilva", "korte", "eper", "meggy", "cseresznye"};
    char **result = foo(t, sizeof(t) / sizeof(char *));
    char **tmp;
    for (tmp = result; *tmp; ++tmp)
        printf("%s\n", *tmp);
    free(result);
    return EXIT_SUCCESS;
}
