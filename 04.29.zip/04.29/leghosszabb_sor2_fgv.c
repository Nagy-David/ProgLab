#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int foo(FILE *f){
	int max = 0;
	char c;
	int db = 0;
	while(1){
		c = fgetc(f);
		if(c == '\n' || c == EOF){
			if(db > max){
				max = db-1;
			}
			db=0;
		}
		if(c==EOF){
			break;
		}
		db++;
	}
	return max;
}
