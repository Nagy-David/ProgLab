#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int legrovidebb_hossz(char **tomb, int meret){
	int min=strlen(tomb[0]);
	int i;
	for(i=0; i<meret;i++){
		if(strlen(tomb[i])<min){
			min=strlen(tomb[i]);
		}
	}
	return min;
}

int legrovidebb_hossz_db(char **tomb, int meret){
	int min=legrovidebb_hossz(tomb,meret);
	int i,db=0;
	for(i=0; i<meret;i++){
		if(strlen(tomb[i])==min){
			db++;
		}
	}
	return db;
}

char **foo(char **tomb, int meret){
	int min= legrovidebb_hossz(tomb,meret);
	int db = legrovidebb_hossz_db(tomb,meret);
	int i,v=0;
	char **uj = (char**)malloc(sizeof(char*)*(db+1));
	for(i=0; i<db+1;i++){
		uj[i]=(char*)malloc(sizeof(char)*(min+1));
	}
	for(i=0; i<meret;i++){
		if(strlen(tomb[i])==min){
			strcpy(uj[v++],tomb[i]);
		}
	}
	uj[v++]=NULL;
	return uj;	
}

