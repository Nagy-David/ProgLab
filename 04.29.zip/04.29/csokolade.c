#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
Magas szintu programoz�si nyelvek 1, 2016. m�jus 18., Sz18 ZH

�rjon programot, amelynek elso parancssori argumentuma egy sz�veges �llom�ny neve!

A program a sz�veges �llom�nyb�l asztallapokat le�r� blokkokat olvas be. 
Egy asztallapot le�r� blokk adatai a k�vetkezok: az elso sor k�t eg�sz 
sz�mot tartalmaz, az asztallap hossz�s�g�nak (h) �s sz�less�g�nek (sz) 
az �rt�k�t, ahol 3 = h = 40 �s 3 = sz = 40. A k�vetkezo h sor mindegyik�ben 
sz darab karakter tal�lhat�, amelyek az asztalon sz�tsz�rt �lelmiszereket 
�rj�k le: a csokol�d�kat p�ld�ul mindig egy 'X' (nagy X betu) karakterekbol 
�ll� 2�2-es n�gyzet szimboliz�lja. Semmilyen m�s �lelmiszert nem jel�l 'X' 
karakter, a t�bbi karakter az asztallapon elhelyezkedo egy�b �lelmiszereket 
�rja le. A csokol�d�k � �rdekes m�don � �gy helyezkednek el az asztallapon, 
hogy nem �rintik egym�st oldalaikkal (sarkosan viszont �rinthetik egym�st!).

A program minden blokk eset�n hat�rozza meg �s �rja a standard kimenetre k�l�n 
sorban, hogy h�ny csokol�d� tal�lhat� az asztallapon!

P�lda �llom�ny (sample.txt)
8 20
....................
....................
....................
........XX..........
........XX..........
....................
....................
....................
9 20
..SSS......XX.......
...........XX.......
..XX.....O........w.
..XX......O...XX..|.
.......XX..O..XX..|.
.O.....XX.........|.
...........XX.......
...XX...|..XX.......
...XX...M...........

*/

int main(int argc, char*argv[]){
	
	FILE *f = fopen(argv[1],"r");
	
	if(f==NULL){
		printf("Nincs ilyen fajl!\n");
		return -1;
	}
	
	int n,m;
	char sor[10];
	while(fgets(sor,10,f)!=NULL){
		int n = atoi(strtok(sor," "));
		int m = atoi(strtok(NULL," "));
		
		char matrix[n][m];
		int i,j;
		
		for(i=0; i<n;i++){
			for(j=0;j<m+1;j++){
				char c = fgetc(f);
				if(c!='\n'){
					matrix[i][j]=c;	
				}	
			}
		}
		
		int db = 0;
		printf("Matrix:\n");
		for(i=0; i<n;i++){
			for(j=0;j<m;j++){
				printf("%c",matrix[i][j]);	
				if(matrix[i][j]=='X'){
					db++;
				}
			}
			printf("\n");
		}
		printf("Csokoladek szama: %d\n",db/4);
		
	}
	
	return 0;
}



