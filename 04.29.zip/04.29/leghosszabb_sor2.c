#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
Magas szintu programoz�si nyelvek 1, 2016. m�jus 18., Sz10 ZH

Leghosszabb sor

�rja meg a myheader.h �llom�nyban deklar�lt foo() f�ggv�nyt, 
amely param�terk�nt megkap egy logikai�llom�ny-azonos�t�t, 
amely egy olvas�sra megnyitott sz�veges �llom�nyt azonos�t! 
A f�ggv�ny hat�rozza meg a sz�veges �llom�ny leghosszabb sor�nak 
hossz�t, �s adja vissza ezt az �rt�ket! �gyeljen r�, hogy a 
sz�veges �llom�ny sorai tetszoleges hossz�s�g�ak lehetnek!

P�lda �llom�ny (sample.txt)
Ej mi a ko! tyukanyo, kend
A szobaban lakik itt bent?
Lam, csak jo az isten, jot ad,
Hogy folvitte a kend dolgat!

A p�lda tesztprogram kimenete
30
*/
int foo(FILE *f){
	int max = 0;
	char c;
	int db = 0;
	while(1){
		c = fgetc(f);
		if(c == '\n' || c == EOF){
			if(db > max){
				max = db-1;
			}
			db=0;
		}
		if(c==EOF){
			break;
		}
		db++;
	}
	return max;
}

int main()
{
    int length;
    FILE *fp = fopen("sample.txt", "r");
    if (fp == NULL)
    {
        fprintf(stderr, "I can\'t open the file!\n");
        exit(1);
    }
    length = foo(fp);
    printf("%d\n", length);
    fclose(fp);
    return EXIT_SUCCESS;
}


