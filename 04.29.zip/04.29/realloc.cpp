#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	
	char *s = (char*)malloc(sizeof(char)*5);
	strcpy(s,"alma");
	puts(s);
	s = (char*)realloc(s,10);
	memset(s,'.',3);
	puts(s);
	
	
	
	
	return 0;
}
