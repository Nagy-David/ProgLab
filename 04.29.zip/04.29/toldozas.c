#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
Toldoz�s-foldoz�s
Magas szintu programoz�si nyelvek 1, 2016. m�jus 18., Sz12 ZH

�rja meg a myheader.h �llom�nyban deklar�lt foo() f�ggv�nyt, amely param�terk�nt
megkapja egy sztringeket tartalmaz� t�mb kezdoc�m�t �s elemsz�m�t, 
valamint egy tov�bbi pozit�v eg�sz sz�mot (n-et)! A f�ggv�ny (elj�r�s) 
hat�rozza meg a t�mb leghosszabb sztringj�nek a hossz�t! Ha ez a sz�m 
nagyobb n-n�l, akkor a f�ggv�ny (elj�r�s) fejezze be a muk�d�s�t! 
Egy�bk�nt pedig mindegyik sztring elej�re sz�rjon be annyi pont ('.') 
karaktert, amennyivel az adott sztring hossza pontosan n-re n�velheto! 
Ha sz�ks�ges, foglaljon helyet a mem�ri�ban az �j, hosszabb sztringek sz�m�ra!

......alma
.......dio
....barack

*/
int max_hossz(char **tomb, int meret){
	int i, max = strlen(tomb[0]);
	for(i=1; i<meret;i++){
		if(strlen(tomb[i])>max){
			max=strlen(tomb[i]);
		}
	}
	return max;
}


void foo(char **tomb, int meret, int n){
	int max=max_hossz(tomb,meret);
	if(max > n){
		return;
	}
	int i,j;
	char **uj = (char**)malloc(sizeof(char*)*meret);
	for(i=0; i<meret;i++){
		uj[i]=(char*)malloc(sizeof(char)*(n+1));
		int v = 0;
		for(j=0; j<n-strlen(tomb[i]);j++){
			uj[i][v++]='.';
		}
		for(j=0; j<strlen(tomb[i]);j++){
			uj[i][v++]=tomb[i][j];
		}
		uj[i][v]='\0';
	}
	for(i=0; i<meret;i++){
		tomb[i]=uj[i];
	}
}


int main()
{
    char *t[3] = {"alma", "dio", "barack"};
    int i;
    foo(t, 3, 10);
    for (i = 0; i < 3; ++i)
        printf("%s\n", t[i]);
    return EXIT_SUCCESS;
}
