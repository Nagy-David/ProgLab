#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
Magas szintu programoz�si nyelvek 1, 2016. m�jus 23., H16 ZH
	
Elimin�ci�

�rja meg a myheader.h �llom�nyban deklar�lt foo() f�ggv�nyt, amely 
param�terk�nt megkap egy sztringet, valamint egy karaktert! A f�ggv�ny 
hozzon l�tre egy �j sztringet, amelyet az eredeti sztringbol a param�terk�nt 
megkapott karakter �sszes elofordul�s�nak elt�vol�t�s�val kapunk! A f�ggv�ny 
visszat�r�si �rt�ke az �j sztring kezdoc�me legyen! �gyeljen r�, hogy az eredeti 
sztring ne v�ltozzon meg!

*/
char *foo(char *s, char c){
	char *uj = (char*)malloc(sizeof(char)*(strlen(s)+1));
	int i,v=0;
	for(i=0; i<strlen(s);i++){
		if(s[i]!=c){
			uj[v++]=s[i];
		}
	}
	uj[v]='\0';
	return uj;
}

int main()
{
    char *result = foo("Debrecen", 'e');
    printf("%s\n", result);
    free(result);
    return EXIT_SUCCESS;
}
