#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
Magas szintu programoz�si nyelvek 1, 2016. m�rcius 30., Sz10 ZH
Bev�s�rl�s
�rjon programot, amely seg�t kisz�molni egy bev�s�rl�s ut�n 
fizetendo pontos �sszeget!

A bemenet t�bb tesztesetet tartalmaz.
Egy teszteset minden sora egy-egy kos�rba helyezett term�k �r�t 
tartalmazza E.CC form�tumban, ahol E eur�ban (E = 0), CC pedig centben 
megadott �rt�k, ut�bbi mindig k�t sz�mjeggyel le�rva (0 = CC < 100). 
A teszteseteket egy olyan sor z�rja, amely az �END� sztringet tartalmazza. 
Felt�telezheto, hogy a kos�rban mindig lesz legal�bb egy term�k.

A program �rja a standard kimenetre a bemenetben is alkalmazott form�tumban 
az egyes v�s�rl�sok v�g�sszeg�t!

P�lda bemenet
3.20
4.30
5.00
END
10.00
END
let�lt�s sz�veges �llom�nyk�nt
A p�lda bemenethez tartoz� kimenet
12.50
10.00
*/

int main(){
	
	double sum = 0;
	char sor[20];
	while(gets(sor)!=NULL){
		
		if(strcmp(sor,"END")==0){
			printf("%.2lf\n",sum);
			sum=0;
		}
		else{
			sum+=atof(sor);
		}
	}
	
	
	return 0;
}




