#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
Holdra sz�ll�s

Magas szintu programoz�si nyelvek 1, 2016. m�rcius 30., Sz10 ZH

�rja meg a myheader.h �llom�nyban deklar�lt foo() f�ggv�nyt, amely param�terk�nt megkap
egy sztringet, valamint k�t pozit�v eg�sz sz�mot (n �s m)! A sztring a Hold felsz�n�nek
egy r�szlet�t �rja le. Mint ismeretes, a Holdon k�l�nb�zo sz�less�gu s�k felsz�nek
�s kr�terek v�ltogatj�k egym�st. A sztringben a '-' (m�nuszjel) karakter egy s�k
felsz�nr�szt, a '.' (pont) karakter pedig egy kr�terr�szt jel�l.

A f�ggv�ny adja vissza azon kr�terek sz�m�t, amelyek legal�bb n, legfeljebb m r�szbol �llnak!
A mint�ban minden kr�tert legal�bb egy s�k felsz�nr�sz hat�rol.

P�lda bemenet
------------ 1 3
--.-.--.- 1 1
-.-..--...- 2 3

A p�lda tesztprogram kimenete
0
3
2

*/


int foo(char *line, int n, int m){
	int db = 0;
	char *token = strtok(line,"-");
	while(token!=NULL){
		printf("token: %s\n",token);
		if(strlen(token)>=n && strlen(token)<= m){
			db++;
		}
		token=strtok(NULL,"-");
	}
	return db;
}

int main()
{
    char line[1000];
    int n, m;
    while (scanf("%s %d %d", line, &n, &m) != EOF)
        printf("%d\n", foo(line, n, m));
    return EXIT_SUCCESS;
}


