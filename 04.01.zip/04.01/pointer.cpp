#include<stdio.h>
#include<stdlib.h>

int main(){
	
	int a = 5;
	int *p = &a; //p egy mutat�
	
	printf("cim: %p\n",p); //c�m
	printf("ertek: %d\n",*p); //�rt�k
	printf("a = %d\n",a); //a = 5
	printf("------------\n");

	/*
	a++;
	printf("cim: %p\n",p);  
	printf("ertek: %d\n",*p); //*p = 6
	printf("a = %d\n",a);   //a = 6
	printf("------------\n");
	*/
	
	/*
	p++;	
	printf("cim: %p\n",p);  //
	printf("ertek: %d\n",*p);
	printf("a = %d\n",a);
	printf("------------\n");
	*/
	
	/*
	(*p)++; //az �rt�ket n�veli 
	printf("cim: %p\n",p);
	printf("ertek: %d\n",*p); //6
	printf("a = %d\n",a); //6
	printf("------------\n");
	*/
	
	
	++*p; //az �rt�ket n�veli 
	printf("cim: %p\n",p);
	printf("ertek: %d\n",*p);
	printf("a = %d\n",a);
	printf("------------\n");
	
	int **q = &p;
	printf("p cim: %p\n",p);
	printf("p ertek: %d\n",*p);
	printf("a = %d\n",a);
	printf("q cim: %p\n",q);
	printf("q ertek: %p\n",*q);
	printf("q ertek: %d\n",**q);
	
	printf("------------\n");
	
	return 0;
}
