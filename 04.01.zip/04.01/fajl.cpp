#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	
	FILE *f = fopen("bemenet.txt","r");
	
	char ut[100];
	printf("Adjon meg egy eleresi utvonalat: ");
	gets(ut);
	printf("\n");
	
	FILE *ki = fopen(ut,"w");

	if(f == NULL){
		printf("Nincs ilyen fajl!\n");
	}
	int n;
	while(fscanf(f,"%d",&n)!=EOF){
		printf("%d\n",n);
		fprintf(ki,"%d\n",n);
	}
	
	fclose(f); 
	fclose(ki);
	
	return 0;
}
