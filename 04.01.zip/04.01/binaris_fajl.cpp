#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	
	FILE *ki = fopen("kimenet.bin","wb");
	
	int tomb[]={1,2,3,10,12,1,0};

	fwrite (tomb , sizeof(int), 7, ki); //
	fclose(ki);
	
	FILE *be = fopen("kimenet.bin","rb");
	int *tomb2 = (int*)malloc(sizeof(int)*7);
	fread (tomb2,sizeof(int),7,be);
	
	int i;
	for(i=0; i<7;i++){
		printf("%d\n",tomb2[i]);
	}
	
	
	
	return 0;
}
