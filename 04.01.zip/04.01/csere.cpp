#include<stdio.h>
#include<stdlib.h>

void csere(int *a, int *b){
	int tmp = *a; //a tmp legyen egyenl� az a mutat� �rt�k�vel
	*a = *b; //a k�t mutat� �rt�k�t megcser�lem 
	*b = tmp; //a b mutat� �rt�ke pedig a tmp-vel legyen egyenl�
}

int main(){
	
	int a = 5;
	int b = 6;
	printf("Csere elott: %d %d\n",a,b);
	csere(&a,&b);
	printf("Csere utan: %d %d\n",a,b);	

	return 0;
}
