#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
Magas szintu programoz�si nyelvek 1, 2015. m�jus 18., H12 ZH

Pizz�k
�rjon programot, amely az elso parancssori argumentumak�nt megadott sz�veges �llom�nyb�l �llom�nyv�gjelig soronk�nt egy-egy pizza adatait olvassa be! Egy sor fel�p�t�se a k�vetkezo:

pizzan�v;�sszetevo[;�sszetevo]�;32cm_�r;45cm_�r

A pizzan�v egy legfeljebb 32 karakter hossz�, csak angol betuket, sz�mjegyeket, k�tojelet (m�nuszjelet) �s sz�k�z karaktert tartalmaz� sztring. Egy �sszetevo egy legfeljebb 32 karakter hossz�, csak angol betuket �s sz�k�z karaktert tartalmaz� sztring. Az �sszetevoket k�t pozit�v eg�sz sz�m k�veti: a 32cm_�r a 32 cm �tm�roju pizza �r�t mutatja, m�g a 45cm_�r a 45 cm �tm�roju pizza �ra. Az adatokat a sorban egy-egy pontosvesszo karakter v�lasztja el egym�st�l.

A program hat�rozza meg �s �rja a standard kimenet elso sor�ba azt, hogy h�ny �sszetevoje van a legt�bb �sszetevovel rendelkezo pizz�(k)nak! A tov�bbi sorokba ezeknek a pizz�knak a nev�t �rja ki az �llom�nyban val� elofordul�suk sorrendj�ben, soronk�nt egyet-egyet!

P�lda bemenet
margareta;paradicsom;mozzarella;840;1640
szalamis;szalami;mozzarella;940;1900
sonkas-gombas;sonka;gomba;mozzarella;1040;2100

A p�lda bemenethez tartoz� kimenet
3
sonkas-gombas

*/

typedef struct pizza{
	char nev[33];
	int feltet;
}pizza;


int main(int argc, char*argv[]){
	
	FILE *f = fopen(argv[1],"r");
	
	if(f==NULL){
		printf("Nincs ilyen fajl!");
		return -1;
	}
	char sor[10000];
	int i,db=0;
	//sorok sz�ma
	while(fgets(sor,10000,f)!=NULL){
		db++;
	}
	//vissza�llunk a f�jl elej�re
	rewind(f);
	
	//db m�ret� lesz a pizz�k t�mbje
	pizza p[db];
	int v = 0;
	int max = -1;
	
	while(fgets(sor,10000,f)!=NULL){
		//az fgets a string v�g�re rakja az entert is
		if(sor[strlen(sor)-1]=='\n'){ //lev�gja az entert a v�g�r�l
			sor[strlen(sor)-1]='\0';
		}
		int j,pontosvesszok = 0;
		for(j=0; j<strlen(sor);j++){
			if(sor[j]==';'){
				pontosvesszok++;
			}
		}
		p[v].feltet = pontosvesszok;
		strcpy(p[v].nev,strtok(sor,";"));
	
		if(p[v].feltet>max){
			max=p[v].feltet;
		}
	
		v++;
	
	}
	printf("%d\n",max-2);
	for(i=0; i<v;i++){
		if(p[i].feltet==max){
			printf("%s\n",p[i].nev);
		}
	}
	
	return 0;
}




