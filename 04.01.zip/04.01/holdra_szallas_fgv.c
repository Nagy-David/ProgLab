#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int foo(char *line, int n, int m){
	int db = 0;
	char *token = strtok(line,"-");
	while(token!=NULL){
		if(strlen(token)>=n && strlen(token)<= m){
			db++;
		}
		token=strtok(NULL,"-");
	}
	return db;
}
