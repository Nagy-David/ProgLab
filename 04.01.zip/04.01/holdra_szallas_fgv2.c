#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int foo(char *s, int n, int m){
	int i,db = 0;
	for(i=0; i<strlen(s);i++){
		if(s[i]=='.'){
			int j = i+1;
			while(s[j]=='.'){
				j++;
			}
			int h = j-i;
			if(h>=n && h<=m){
				db++;
			}
			i = j;
		}
	}
	return db;
	
}
