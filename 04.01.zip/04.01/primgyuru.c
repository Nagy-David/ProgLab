#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
/*
Magas szintu programoz�si nyelvek 1, 2017. janu�r 3., K8 ZH

Pr�mgyuru
A pr�mgyuru nagyon �rt�kes eljegyz�si aj�nd�k.
Nagy ritkas�gnak sz�m�t, �s emiatt fokozottan oda szoktak r� figyelni. 
Egy olyan gyururol van sz�, amelynek k�veit pozit�v eg�sz sz�mok alkotj�k 
�gy, hogy b�rmely k�t, k�zvetlen�l egym�s szomsz�ds�g�ban l�vo sz�m �sszeg�nek 
pr�msz�mnak kell lennie. (A pr�msz�m olyan sz�m, amelynek � eltekintve 
az elojeltol � az 1-en �s �nmag�n k�v�l nincs m�s eg�sz oszt�ja.) R�ad�sul, 
ha egy pr�mgyuru n darab k�vet tartalmaz, akkor a k�vek k�z�tt kell 
szerepelnie 1-tol n-ig az �sszes pozit�v eg�sz sz�mnak. Ha belegondolunk, 
ilyen felt�telek mellett p�ld�ul nem is lehet p�ratlan darabsz�m� kobol �ll� 
pr�mgyurut k�sz�teni.

�rjon programot, amelynek legal�bb ketto darab parancssori argumentuma van, 
mindegyik egy pozit�v eg�sz sz�m! A program d�ntse el, hogy alkothatnak-e a 
megadott sorrendben a parancssori argumentumok pr�mgyurut vagy sem, �s �rja 
a standard kimenetre a pr�mgyuru �rt�k�t (az ot alkot� sz�mok �sszeg�t), 
valamint tole pontosan egy sz�k�z karakterrel elv�lasztva a �YES� liter�lt, 
ha igen, vagy csup�n a �NO� liter�lt, ha nem! Ne felejtsen el a ki�rt sztring 
m�g� k�zvetlen�l egy soremel�s karaktert �rni!

Parancssori argumentumok
1 4 3 2 5 6

A futtat�s eredm�nye a standard kimeneten
21 YES

Parancssori argumentumok
1 2 3 4 5 6

A futtat�s eredm�nye a standard kimeneten
NO
*/
int prim_e(int n){
	if(n==0 || n==1){
		return 0;
	}
	int i;
	for(i=2; i<=n/2;i++){
		if(n%i==0){
			return 0;
		}
	}
	return 1;
}

int hasonlit(const void *a, const void *b){
	return *(int*)a - *(int*)b;
}

int main(int argc, char*argv[]){
	
	int i;
	int sum=0;
	int flag = 1;
	int meret = argc-1;
	int tomb[meret];
	
	for(i=1; i<argc;i++){
		sum+=atoi(argv[i]);
		tomb[i-1]=atoi(argv[i]);
	}
	
	for(i=0; i<meret-1;i++){
		flag &= prim_e(tomb[i]+tomb[i+1]);
		if(!flag)
			break;
	}
	flag &= prim_e(tomb[0]+tomb[meret-1]);	
	qsort(tomb,meret,sizeof(int),hasonlit);

	for(i=0; i<argc-1;i++){
		flag &= tomb[i]==i+1;
		if(!flag)
			break;
	}

	if(flag){
		printf("%d YES\n",sum);
	}
	else{
		printf("NO\n");
	}
	
	return 0;
}

