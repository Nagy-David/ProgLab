int *reverse(int *tomb, int meret){
	int *uj = (int*)malloc(sizeof(int)*meret); 
	int i;
	for(i=0; i<meret;i++){
		uj[i]=tomb[meret-1-i];
	}
	return uj;
}
