#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
�rjon f�ggv�nyt, mely egy bemeneti sztringben l�v�
legt�bbsz�r el�fordul� kisbet�t adja vissza.

Be:
almafa?????????
eper
aaeek

Ki:
a
e
a

*/
char max_karakter(char *s){
	int db[256]={0};
	int i;
	for(i=0; i<strlen(s);i++){
		db[s[i]]++;
	}
	/*	
	for(i=0; i<256;i++){
		if(db[i]!=0){
			printf("%c: %d\n",i,db[i]);
		}
	}*/	
	int max=db[0];
	char max_kar = 0;
	for(i=97; i<=122;i++){
		if(db[i]>max /*&& islower(i) */ ){
			max=db[i];
			max_kar = i;
		}
	}
	return max_kar;
}

int main(){
	
	char s[30];
	gets(s);
	printf("A legtobbszor elofordulo karakter: %c\n",max_karakter(s));
	
	return 0;
}
