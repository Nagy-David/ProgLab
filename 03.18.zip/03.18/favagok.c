#include<stdio.h>
#include<stdlib.h>
/*
	
Lumberjack Sequencing
Another tale of lumberjacks? Let's see�

The lumberjacks are rude, bearded workers, while foremen tend to be bossy and simple-minded. The foremen like to harass the lumberjacks by making them line up in groups of ten, ordered by the length of their beards. The lumberjacks, being of different physical heights, vary their arrangements to confuse the foremen. Therefore, the foremen must actually measure the beards in centimeters to see if everyone is lined up in order.

Your task is to write a program to assist the foremen in determining whether or not the lumberjacks are lined up properly, either from shortest to longest beard or from longest to shortest.

Input Specification
The input starts with a line containing a single integer N (0 < N < 20), which is the number of groups to process. Following this are N lines, each containing ten distinct positive integers less than 100.

Output Specification
There is a title line containing �Lumberjacks:�, then one line per set of beard lengths, containing the word �Ordered� if the lumberjacks are lined up properly, or �Unordered�, otherwise.

Sample Input
3
13 25 39 40 55 62 68 77 88 95
88 62 77 20 40 10 99 56 45 36
91 78 61 59 54 49 43 33 26 18

Lumberjacks:
Ordered
Unordered
Ordered

*/
int main(){	
	int n;
	scanf("%d",&n);
	int i,j;
	printf("Lumberjacks:\n");
	for(i=0; i<n;i++){
		int tomb[10];
		for(j=0; j<10;j++){
			scanf("%d",&tomb[j]);
		}
		int no = 0, csokken = 0;
		for(j=0; j<9;j++){
			if(tomb[j]>tomb[j+1]){
				csokken = 1;
			}
			if(tomb[j]<tomb[j+1]){
				no = 1;
			}
		}
		if(no && csokken){
			printf("Unordered\n");
		}
		else{
			printf("Ordered\n");
		}		
	}
	return 0;
}





