#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
2015.04.15. SZ12
�ral�togat�k
A tanulm�nyi rendszerben h�trol h�tre r�gz�teni kell, hogy egy hallgat� jelen
volt-e egy adott �r�n vagy sem. �rjon egy programot, amely a standard bemenetrol 
�llom�nyv�gjelig hallgat�k jelenl�ti adatait olvassa be soronk�nt, �sszesen 
legfeljebb 20-at! Egy sor fel�p�t�se a k�vetkezo:

hallgat�_neve/jelenl�tek

A hallgat�_neve egy legfeljebb 30 karakter hossz�, csak angol betuket, k�tojelet
(m�nuszjelet) �s sz�k�z karaktert tartalmaz� egyedi sztring. A jelenl�tek egy
pontosan 15 karakter hossz�s�g�, kiz�r�lag 0 �s 1 karakterekbol �ll� sztring,
ahol az i-edik helyen �ll� karakter az i-edik heti jelenl�tre utal: 0, ha nem
volt jelen a hallgat�, 1, ha igen. Az adatokat a sorban egy-egy oszt�sjel (perjel)
karakter v�lasztja el egym�st�l.

A program a hallgat�k �rai jelenl�teinek sz�ma alapj�n rendezze cs�kkeno sorba az 
adatokat! Ha t�bb olyan hallgat� is lenne, akik egyform�n sokszor voltak jelen az 
�r�kon, akkor oket a nev�k szerint lexikografikusan n�vekvo sorrendbe tegye a program,
majd v�g�l �rja a standard kimenetre azon hallgat�k neveinek ily m�don
rendezett list�j�t, akik nem hi�nyoztak h�romn�l t�bbsz�r az �r�kr�l!

P�lda bemenet
Teszt Elek/110110110110110
Meno Jeno/111101111011110
Bena Bela/111111111111111

A p�lda bemenethez tartoz� kimenet
Bena Bela
Meno Jeno

*/



typedef struct hallgato{
	char nev[31];
	int jelenlet;
}hallgato;

void kiir(hallgato h[], int meret){
	int i;
	for(i=0; i<meret;i++){
		if(h[i].jelenlet >= 12){
			printf("%s\n",h[i].nev);
		}		
	}
}

int hasonlit(const void *a, const void *b){	
	hallgato *h1 = (hallgato*)a;
	hallgato *h2 = (hallgato*)b;
		
	if(h1->jelenlet > h2->jelenlet){
		return -1;
	}
	else if(h1->jelenlet < h2->jelenlet){
		return 1;
	}
	else{
		return strcmp(h1->nev,h2->nev);
	}	
}
int main(){	
	char sor[37];
	hallgato h[20];
	int db=0;	
	while(gets(sor)!=NULL){
		strcpy(h[db].nev,strtok(sor,"/"));
		char *token = strtok(NULL,"/");
		int i;
		h[db].jelenlet = 0;
		for(i=0; i<strlen(token);i++){
			if(token[i]=='1'){
				h[db].jelenlet++;
			}
		}
		db++;
	}	
	qsort(h,db,sizeof(hallgato),hasonlit);
	kiir(h,db);
	return 0;
}
