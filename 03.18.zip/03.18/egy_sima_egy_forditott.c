#include <stdio.h>
#include <stdlib.h>

/*
P�lda bemenet
1 7
2 9 -3
3 4 -1 7
0

A p�lda bemenethez tartoz� kimenet
7
-3 9
7 -1 4

*/


int *reverse(int *tomb, int meret){
	int *uj = (int*)malloc(sizeof(int)*meret); 
	int i;
	for(i=0; i<meret;i++){
		uj[i]=tomb[meret-1-i];
		/*
		meret = 5
		i = 0
		uj[0] = tomb[5-1-0] --> uj[0] = uj[4]
		uj[1] = tomb[5-1-1] --> uj[1] = uj[3]
		...
		*/
	}
	return uj;
}

int main()
{
  int *reverse( int *, int );
  for ( ; ; )
  {
    int n, i, *t, *p;
    scanf( "%d", &n );
    if ( n == 0 )
      break;
    t = ( int * )malloc( n * sizeof( int ) );
    for ( i = 0; i < n; ++i )
      scanf( "%d", &t[ i ] );
    p = reverse( t, n );
    for ( i = 0; i < n; ++i )
    {
      if ( i > 0 )
        putchar( ' ' );
      printf( "%d", p[ i ] );
    }
    putchar( '\n' );
    free( p );
    free( t );
  }
  return EXIT_SUCCESS;
}
