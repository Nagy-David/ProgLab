#include<stdio.h>
#include<string.h>
#include<stdlib.h>
/*
	
H�lgykoszor�
�rjon programot, amely a standard bemenetrol soronk�nt egy-egy szem�ly adatait
olvassa �llom�nyv�gjelig, legfeljebb 200-at! Egy sor alakja a k�vetkezo:

vezet�kn�v keresztn�v nem sz�let�si_�v

A vezet�kn�v �s a keresztn�v legfeljebb 20 karakter hossz�s�g�, sz�k�z
karaktert nem tartalmaz� sztring, a nem az 'F' vagy 'N' karakterek valamelyike,
m�g a sz�let�si_�v egy eg�sz sz�m.

A program �rja a standard kimenetre a 18 �vesn�l idosebb (az 1996 elott sz�letett)
h�lgyek vezet�knev�t, keresztnev�t �s �letkor�t! A kimeneten a h�lgyek adatai
�letkoruk szerint cs�kkeno sorrendben, azonos �letkorok eset�n a vezet�knev�k
szerinti �b�c�rendben, azonos �letkorok �s vezet�knevek eset�n pedig a keresztnev�k
szerinti �b�c�rendben jelenjenek meg!

P�lda bemenet

Kiss Nora N 1991
Hepele Mark F 1996
Aranyosi Dora N 1989
Bill Gates F 1955
Kiss Annamaria N 1991
Nagy Eva N 1999

A p�lda bemenethez tartoz� kimenet
Aranyosi Dora 25
Kiss Annamaria 23
Kiss Nora 23
*/

typedef struct szemely{
	char vnev[21];
	char knev[21];
	char nem;
	int ev;
}szemely;

int hasonlit(const void *a, const void *b){
	szemely *sz1 = (szemely*)a;
	szemely *sz2 = (szemely*)b;
	
	if(sz1->ev > sz2->ev){
		return 1;
	}
	else if(sz1->ev < sz2->ev){
		return -1;
	}
	else if(strcmp(sz1->vnev,sz2->vnev)==0){
		return strcmp(sz1->knev,sz2->knev);
	}
	else{
		return strcmp(sz1->vnev,sz2->vnev);
	}
	
}

int main(){
	
	szemely sz[200];
	int v = 0;
	char sor[49];
	
	while(gets(sor)!=NULL){			
		szemely seged;			
				
		strcpy(seged.vnev,strtok(sor," "));
		strcpy(seged.knev,strtok(NULL," "));
		seged.nem = strtok(NULL," ")[0];
		seged.ev = atoi(strtok(NULL," "));
			
		if(seged.ev < 1996 && seged.nem == 'N'){
			sz[v++]=seged; //sz[v] = seged ; v++;
		}
	}
	qsort(sz,v,sizeof(szemely),hasonlit);
	int i;
	for(i=0; i<v;i++){
		printf("%s %s %d\n",sz[i].vnev,sz[i].knev,2014-sz[i].ev);
	}
	
	return 0;
}


