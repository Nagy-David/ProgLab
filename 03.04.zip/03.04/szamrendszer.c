/*
	
Sz�mrendszerv�lt�s
�rjon f�ggv�nyt, amely visszat�r�si �rt�kk�nt meghat�rozza, hogy a param�terek�nt
megkapott sztringben le�rt hexadecim�lis alak� nemnegat�v eg�sz sz�mnak mennyi
a decim�lis �rt�ke! Felteheto, hogy ez az �rt�k kisebb, mint 2^31.

P�lda bemenet
0
16
A5
ABBA

A p�lda bemenethez tartoz� kimenet
0
22
165
43962
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
int hex2dec(char *s ){
	
	int i;
	int dec = 0;
	int h = 1;
	for(i=strlen(s)-1; i>=0;i--){
		if(s[i]>='A' && s[i]<='F'){
			dec+=(s[i]-55)*h;
		}
		if(s[i]>='a' && s[i]<='f'){
			dec+=(s[i]-87)*h;
		}
		if(s[i]>='0' && s[i]<='9'){
			dec+=(s[i]-48)*h;
		}
		h*=16;
	}
	return dec;
	
}

int main()
{
  char line[ 1000 ];
  int hex2dec( char * );
  while ( gets( line ) != NULL )
    printf( "%d\n", hex2dec( line ) );
  return EXIT_SUCCESS;
}
