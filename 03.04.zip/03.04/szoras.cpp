#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
/*
�rjunk programot, mely 20 darab v�letlen eg�sz sz�m ([1-100]) sz�r�s�t kisz�molja.
*/

#define N 20

int * feltolt(){
	srand(time(NULL));
	int i;
	int *tomb = (int *)malloc(sizeof(int)*N);
	for(i=0; i<N;i++){
		tomb[i]=rand()%100+1;
	}
	return tomb;
}
void kiir(int *tomb){
	int i;
	printf("Tomb:\n");
	for(i=0; i<N;i++){
		printf("%d ",tomb[i]);
	}
}

double atlag(int *tomb){
	int i,szum = 0;
	for(i=0; i<N;i++){
		szum+=tomb[i];
	}
	return (double)szum/(double)N;
}

double szoras(int *tomb){
	double avg = atlag(tomb);
	double szum = 0;
	int i;
	for(i=0; i<N;i++){
		szum+=pow(tomb[i]-avg,2);
	}
	return sqrt(szum/((double)N-1));
}

int main(){
	int * tomb = feltolt();
	kiir(tomb);
	printf("\nAtlag: %lf\n",atlag(tomb));
	printf("Szoras: %lf\n",szoras(tomb));
	
	return 0;
}


