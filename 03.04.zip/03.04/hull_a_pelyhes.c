/*
	
Hull a pelyhes
Mint ismeretes, a T�lap� minden �vben december 6-�n este megl�togatja a gyerekeket,
j�kat �s rosszakat egyar�nt, �s megjutalmazza oket att�l f�ggoen, hogy mennyi C nyelvu
programot �rtak a legut�bbi l�togat�sa �ta eltelt idoben.

�rjon C f�ggv�nyt, amely param�terk�nt megkapja egy �rv�nyes d�tum h�rom eg�sz
�rt�ku komponens�t: egy �vsz�mot, egy h�napsz�mot �s egy napsz�mot, ebben a sorrendben!
A f�ggv�ny visszat�r�si �rt�ke legyen az az eg�sz sz�m, amely jelzi, hogy mennyit kell
m�g aludni a T�lap� k�vetkezo l�togat�s�ig (1 alv�s/�jszaka �rt�kkel sz�molva �s a napk�zbeni
alv�sokt�l eltekintve)! A f�ggv�ny specifik�ci�ja a k�vetkezo legyen:

P�lda bemenet
2014 12 05
2014 12 06
2014 12 07
2015 12 05
2015 12 06
2015 12 07

A p�lda bemenethez tartoz� kimenet
1
0
364
1
0
365
*/
int szokoev_e(int ev){
	return (ev%4==0 && ev%100!=0) || ev%400==0;
}
int napok_szama(int ev, int honap, int nap){
	int napok = 0;
	int ho[12]= {31,28,31,30,31,30,31,31,30,31,30,31};
	int i;
	for(i=0; i<honap-1;i++){
		if(szokoev_e(ev) && i==1){
			napok++;
		}
		napok+=ho[i];
	}
	return napok+nap;
}
int next_arrival(int ev, int honap, int nap){
	if(honap < 12 || (honap==12 && nap <= 6) ){
		printf("napok: %d\n",napok_szama(ev,honap,nap));
		printf("napok: %d\n",napok_szama(ev,12,6));
		return napok_szama(ev,12,6)-napok_szama(ev,honap,nap);
	}
	else{
	    printf("napok: %d\n",napok_szama(ev,12,31));
		printf("napok: %d\n",napok_szama(ev,honap,nap));
		printf("napok: %d\n",napok_szama(ev+1,12,6));
		return napok_szama(ev,12,31)-napok_szama(ev,honap,nap)+napok_szama(ev+1,12,6);
	}
}

#include <stdio.h>
#include <stdlib.h>
int main()
{
  int year, month, day;
  int next_arrival(int, int, int);
  while (scanf("%d %d %d", &year, &month, &day) != EOF)
  {
    int res = next_arrival(year, month, day);
    printf("%d\n", res);
  }
  return EXIT_SUCCESS;
}
