int szokoev_e(int ev){
	return (ev%4==0 && ev%100!=0) || ev%400==0;
}


int napok_szama(int ev, int honap, int nap){
	int napok = 0;
	int ho[12]= {31,28,31,30,31,30,31,31,30,31,30,31};
	int i;
	for(i=0; i<honap-1;i++){
		if(szokoev_e(ev) && i==1){
			napok++;
		}
		napok+=ho[i];
	}
	return napok+nap;
}


int next_arrival(int ev, int honap, int nap){
	if(honap < 12 || (honap==12 && nap <= 6) ){
		//printf("napok: %d\n",napok_szama(ev,honap,nap));
		//printf("napok: %d\n",napok_szama(ev,12,6));
		return napok_szama(ev,12,6)-napok_szama(ev,honap,nap);
	}
	else{
		return napok_szama(ev,12,31)-napok_szama(ev,honap,nap)+napok_szama(ev+1,12,6);
	}
}

