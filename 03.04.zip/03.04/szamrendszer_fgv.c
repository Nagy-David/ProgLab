#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int hex2dec(char *s ){
	
	int i;
	int dec = 0;
	int h = 1;
	for(i=strlen(s)-1; i>=0;i--){
		if(s[i]>='A' && s[i]<='F'){
			dec+=(s[i]-55)*h;
		}
		if(s[i]>='a' && s[i]<='f'){
			dec+=(s[i]-87)*h;
		}
		if(s[i]>='0' && s[i]<='9'){
			dec+=(s[i]-48)*h;
		}
		h*=16;
	}
	return dec;
	
}
