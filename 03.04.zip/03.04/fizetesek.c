#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
	
Fizet�sek
�rjon programot, amely a standard bemenetrol soronk�nt egy-egy szem�ly nev�t,
lak�s�nak telep�l�s�t �s annak ir�ny�t�sz�m�t, valamint fizet�s�t olvassa be!
A felsorolt adatok egym�st�l pontosvesszo karakterrel vannak elv�lasztva.
Egy-egy sor maxim�lis hossza nem haladja meg a 120 karaktert.
A program hat�rozza meg �s �rja a standard kimenetre soronk�nt azoknak a szem�lyeknek a nev�t,
akik a 4032-es ir�ny�t�sz�m� telep�l�sen laknak!

P�lda bemenet
Gipsz Elek;Debrecen;4032;100000
Mezei Vir�g;Balassagyarmat;2660;150000
Bekre P�l;Budapest;1081;200000
Vincs Eszter;Debrecen;4032;250000
Beviz Elek;Tiszadob;4456;300000
H�t Izs�k;Debrecen;4032;350000
Lapos Elem�r;Zalaegerszeg;8900;400000

A p�lda bemenethez tartoz� kimenet
Gipsz Elek
Vincs Eszter
H�t Izs�k
*/

int main(){
	char sor[121];
	while(gets(sor)!=NULL){
		char nev[121];
		char * token = strtok(sor,";");
		strcpy(nev,token);
		token = strtok(NULL,";");
		token = strtok(NULL,";");
		int irsz = atoi(token);		
		if(irsz == 4032){
			printf("%s\n",nev);
		}	
	}
	return 0;
}
