#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
	
Pizz�k
�rjon programot, amely a standard bemenetrol �llom�nyv�gjelig soronk�nt egy-egy pizza
adatait olvassa be! Egy sor fel�p�t�se a k�vetkezo:

pizzan�v;�sszetevo[;�sszetevo]�;32cm_�r;45cm_�r

A pizzan�v egy legfeljebb 32 karakter hossz�, csak angol betuket,
sz�mjegyeket, k�tojelet (m�nuszjelet) �s sz�k�z karaktert tartalmaz� sztring.
Egy �sszetevo egy legfeljebb 32 karakter hossz�, csak angol betuket �s sz�k�z
karaktert tartalmaz� sztring. Az �sszetevoket k�t pozit�v eg�sz sz�m k�veti:
a 32cm_�r a 32 cm �tm�roju pizza �r�t mutatja, m�g a 45cm_�r a 45 cm �tm�roju pizza �ra.
Az adatokat a sorban egy-egy pontosvesszo karakter v�lasztja el egym�st�l.

A program hat�rozza meg �s �rja a standard kimenetre annak a pizz�nak a nev�t,
amelynek a legt�bb �sszetevoje van! Ha t�bb olyan pizza is lenne, amely megfelelne
ennek a krit�riumnak, akkor k�z�l�k a felsorol�sban legelsok�nt szereplonek a nev�t v�lassza a program!

P�lda bemenet
margareta;paradicsom;mozzarella;840;1640
szalamis;szalami;mozzarella;940;1900
sonkas-gombas;sonka;gomba;mozzarella;1040;2100

A p�lda bemenethez tartoz� kimenet
sonkas-gombas

*/
int pontosvesszo_db(char *s){
	int i,db=0;
	for(i=0; i<strlen(s);i++){
		if(s[i]==';'){
			db++;
		}
	}
	return db;
}
int main(){
	char sor[10000];
	int max=-1;
	char max_nev[33];
	while(gets(sor)!=NULL){
		int db = pontosvesszo_db(sor);
		if(db>max){
			max=db;
			strcpy(max_nev,strtok(sor,";"));
		}
	}
	printf("%s\n",max_nev);	
	return 0;
}





