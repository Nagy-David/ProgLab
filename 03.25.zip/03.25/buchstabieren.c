#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*	
Magas szintu programoz�si nyelvek 1, 2015. j�nius 2., K14 ZH

Buchstabieren Sie, bitte!
�rjon programot, amely a standard bemenetrol �llom�nyv�gjelig soronk�nt
angol betuk alkotta, egym�st�l pontosan egy sz�k�z karakterrel elv�lasztott
szavakat olvas be! A sorokban a szavak darabsz�ma, illetve az egyes szavak hossza 
�pp�gy, mint a teljes sorok�, nincs korl�tozva.

A program �rja a standard kimenetre a beolvasott szavak elso betuit,
minden sorba pontosan annyit, ah�ny sz� a bemenet megfelelo sor�ban szerepelt!

P�lda bemenet
Tango oscar mike
alfa november delta
Juliett echo romeo romeo yankee

A p�lda bemenethez tartoz� kimenet
Tom
and
Jerry
*/
int main(){
	
	char sor[1000000];
	while(gets(sor)!=NULL){
		char *token = strtok(sor," ");
		while(token!=NULL){
			printf("%c",token[0]);
			token = strtok(NULL," ");
		}
		printf("\n");
	}
	
	return 0;
}
