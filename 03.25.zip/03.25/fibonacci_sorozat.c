#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
/*
Magas szintu programoz�si nyelvek 1, 2015. j�nius 2., K14 ZH
	
Fibonacci-sorozat
�rjon programot, amely eld�nti, hogy parancssori argumentumai
a Fibonacci-sorozat elemei-e! Ha minden parancssori argumentum
eleme a Fibonacci-sorozatnak, akkor a programja a �YES�,
ellenkezo esetben a �NO� sz�veget �rja a standard kimenetre!
A Fibonacci-sorozat elso eleme a 0, m�sodik eleme az 1, �s
minden tov�bbi eleme az adott elemet megelozo k�t elem �sszege.
(Az egyszerus�g kedv��rt felt�telezheti, hogy a program �sszes
parancssori argumentuma t�lcsordul�s n�lk�l �tkonvert�lhat� int
t�pus� eg�sz sz�mm�.)

P�lda parancssori argumentumok
0 1 1 2 3 5 8 13 21 34 55 89 144
4 6 7 9 10 11 12 14 15 16 17 18 19 20
let�lt�s sz�veges �llom�nyk�nt
A p�ld�hoz tartoz� kimenet
YES
NO
*/
int fibonacci_e(int n)
        {
            int a = 0;
            int b = 1;
            if (n==a || n==b) return 1;
            int c = a+b;
            while(c<=n)
            {
                if(c == n) return 1;
                a = b;
                b = c;
                c = a + b;
            }
            return 0;
        }
int main(int argc, char *argv[]){
	int i;
	int flag = 1;
	for(i=1; i<argc;i++){
		if(!fibonacci_e(atoi(argv[i]))){
			flag=0;
			break;
		}
	}
	if(flag){
		printf("YES\n");
	}
	else{
		printf("NO\n");
	}
	
	
	return 0;
}







