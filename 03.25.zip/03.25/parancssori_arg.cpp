#include<stdio.h>
#include<stdlib.h>

//az els� parancssori argumentum mindig a program neve �s el�r�si �tvonala
//argc -> h�ny db argumentum van
//argv -> az argumentumok t�mbje (minden param�ter egy sztring)

int main(int argc, char *argv[]){
	
	int i;
	for(i=0; i<argc;i++){
		printf("%s\n",argv[i]);
	}
	
	return 0;
}
