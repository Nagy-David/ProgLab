#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
Magas szintu programoz�si nyelvek 1, 2015. m�jus 20., Sz12 ZH

A legkisebb is sz�m�t!
�rjon programot, amely legal�bb egy darab,
de egy�bk�nt tetszoleges sz�m� pozit�v eg�sz sz�mot kap
parancssori argumentumk�nt, �s a standard kimenetre �rja e
sz�mok k�z�l a legkisebbnek az �rt�k�t!

P�lda parancssori argumentumok
1 2 3 4 5

A p�ld�hoz tartoz� kimenet
1
*/
int main(int argc, char *argv[]){
	int i, min = atoi(argv[1]);
	for(i=2; i<argc; i++){
		int n = atoi(argv[i]);
		if(n<min){
			min=n;
		}
	}
	printf("%d\n",min);
	return 0;
}

