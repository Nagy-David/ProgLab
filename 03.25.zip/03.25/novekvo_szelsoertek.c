#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
Magas szintu programoz�si nyelvek 1, 2016. m�rcius 30., Sz18 ZH

N�vekvo sz�lso�rt�kek
�rjon programot, amely a standard bemenetrol legfeljebb 50,
eg�sz sz�mokat tartalmaz� sort olvas �llom�nyv�gjelig (EOF)!
Minden sor elso sz�ma egy n pozit�v eg�sz sz�m, amely egy sorozat
elemeinek a darabsz�m�t adja meg. A sorban tal�lhat� tov�bbi n darab sz�m a sorozat n darab eleme.

A program �rja a standard kimenetre a beolvasott sorok sorsz�mait
egym�st�l pontosan egy sz�k�zzel elv�lasztva, a benn�k le�rt sorozatok
sz�lso�rt�keinek (maximum�nak �s minimum�nak) �sszege szerint n�vekvo
sorrendben! Ha k�t vagy t�bb sorozat eset�ben is azonos lenne ez az �rt�k,
akkor azok sorsz�mait a beolvas�suk sorrendj�ben �rja a kimenetre!
Figyelem: a kimenetre �rt utols� sorsz�mot nem k�veti sz�k�z karakter,
viszont ezt az egyetlen sort is soremel�s karakter z�rja!

P�lda bemenet
5 1 2 3 4 5
3 6 7 8
2 6 9
1 9

A p�lda bemenethez tartoz� kimenet
1 2 3 4

*/
typedef struct sorozat{	
	int sorszam;
	int osszeg;
}sorozat;

int min_max_osszeg(int *tomb, int meret){
	int max=tomb[0];
	int min=tomb[0];
	int i;
	for(i=1; i<meret;i++){
		if(tomb[i]>max){
			max=tomb[i];
		}
		if(tomb[i]<min){
			min=tomb[i];
		}
	}
	return min+max;
}

int hasonlit(const void *a, const void *b){
	sorozat *s1 = (sorozat*)a;
	sorozat *s2 = (sorozat*)b;
	return s1->osszeg-s2->osszeg;	
	/*
	if(s1->osszeg>s2->osszeg){
		return 1;
	}
	else if(s1->osszeg<s2->osszeg){
		return -1;
	}
	else{
		return 0;
	}
	*/
}

int main(){
	int n;
	sorozat s[50];
	int db = 0;
	while(scanf("%d",&n)!=EOF){
		int tomb[n];
		int i;
		for(i=0; i<n;i++){
			scanf("%d",&tomb[i]);
		}
		s[db].osszeg = min_max_osszeg(tomb,n);
		s[db].sorszam = db+1;
		db++;
	}
	qsort(s,db,sizeof(sorozat),hasonlit);
	int i;
	for(i=0; i<db;i++){
		if(i!=db-1){
			printf("%d ",s[i].sorszam);
		}else{
			printf("%d\n",s[i].sorszam);
		}	
	}
	return 0;
}










