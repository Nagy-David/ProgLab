#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*	
Magas szintu programoz�si nyelvek 1, 2015. okt�ber 27., K12 ZH

Minyonok
A minyonok t�rt�nete az idok kezdet�tol ered. A minyonok s�rga egysejtu organizmusk�nt kezdt�k, �s fejlodtek a korokon �t, �s mindig a leggr�sabb gazd�kat szolg�lt�k. Mivel ezeket a gazd�kat � a T-Rextol Nap�leonig � folytonosan elvesz�tett�k, a minyonoknak most nincs kit szolg�lniuk, �s m�ly depresszi�ba zuhantak.

�m egy Kevin nevu minyonnak esz�be jut egy terv. K�t t�rs�val az oldal�n neki akar v�gni a vil�gnak, hogy megkeress�k azt az �j gonosz fon�k�t, akit a fajt�juk k�vethet. Ahhoz, hogy a terve sikerrel j�rjon, azonban alaposan meg kell fontolnia, hogy melyik k�t t�rs�val v�g neki az �tnak. Az �n feladata, hogy �rjon Kevin sz�m�ra egy programot, amely a standard bemenetrol �llom�nyv�gjelig minyonok adatait olvassa be soronk�nt, �sszesen legal�bb 2-t, legfeljebb 20-at. Egy sor fel�p�t�se a k�vetkezo:

minyon_neve;�hs�g;lelkesed�s;nadr�g_m�rete

A minyon_neve egy legfeljebb 30 karakter hossz�, csak angol betuket tartalmaz� egyedi sztring. Az �hs�g �s a lelkesed�s egyar�nt 0 �s 100 k�z�tti eg�sz sz�m, m�g a nadr�g_m�rete az �S�, �L�, �XL� �s �XXL� sztringek egyike. Az adatokat a sorban egy-egy pontosvesszo (;) karakter v�lasztja el egym�st�l.

K�t minyon k�z�l az a jobb �tit�rs, amelyik lelkesebb, k�t azonosan lelkes minyon eset�ben pedig a nev�k lexikografikus sorrendj�nek megfeleloen rangsorolja oket Kevin.

A kimenetre pontosan k�t sort kell �rni, melyek egy-egy minyon nev�t, �hs�g�t, valamint a nadr�gj�nak a m�ret�t tartalmazz�k

minyon_neve �hs�g (nadr�g_m�rete)

form�tumban. Az elso sorba a legjobb �tit�rsnak sz�m�t�, a m�sodik sorba pedig a m�sodik legalkalmasabb minyon adatai ker�ljenek!

P�lda bemenet
Bob;87;100;S
Dave;43;10;L
Stuart;50;30;L
Jerry;40;20;XL

A p�lda bemenethez tartoz� kimenet
Bob 87 (S)
Stuart 50 (L)

*/
typedef struct minyon{
	char nev[31];
	int ehseg;
	int lelkesedes;
	char meret[4];
}minyon;

int hasonlit(const void *a, const void*b){
	minyon *m1 = (minyon*)a;
	minyon *m2 = (minyon*)b;
	int kul = m2->lelkesedes-m1->lelkesedes;
	
	if(kul==0){
		return strcmp(m1->nev,m2->nev);
	}
	else{
		return kul;
	}
}
int main(){
	char sor[50];
	minyon m[20];
	int db=0;
	
	while(gets(sor)!=NULL){
		
		strcpy(m[db].nev,strtok(sor,";"));
		m[db].ehseg = atoi(strtok(NULL,";"));
		m[db].lelkesedes = atoi(strtok(NULL,";"));
		strcpy(m[db].meret,strtok(NULL,";"));
		db++;
		
	}
	qsort(m,db,sizeof(minyon),hasonlit);
	int i;
	for(i=0; i<2;i++){
		printf("%s %d (%s)\n",m[i].nev,m[i].ehseg,m[i].meret);
	}
	
	
	return 0;
}



