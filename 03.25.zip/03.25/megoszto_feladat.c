#include<stdio.h>
#include<stdlib.h>
/*
Magas szintu programoz�si nyelvek 1, 2017. m�jus 29., H16 ZH

Megoszt� feladat
�rjon programot, amely a standard bemenet soraib�l pozit�v eg�sz 
sz�mokat olvas �llom�nyv�gjelig (EOF-ig)! Minden sor elso �rt�ke 
(n) azt mondja meg, hogy a sor h�ny tov�bbi sz�mot fog tartalmazni. 
A program rendezze a soronk�nt beolvasott sz�mokat (pozit�v eg�sz �rt�ku) 
oszt�ik sz�ma szerint n�vekvo sorrendbe! Amennyiben k�t vagy t�bb sz�mnak 
is azonos darabsz�m� oszt�ja lenne, akkor oket nagys�guk szerint �ll�tsa 
n�vekvo sorrendbe! Minden rendezett sz�msorozatot k�l�n sorba �rjon ki, a 
sorozat elemeit pontosan egy sz�k�z karakterrel elv�lasztva egym�st�l!

P�lda bemenet
10 1 2 3 4 5 6 7 8 9 10
10 11 12 13 14 15 16 17 18 19 20

A p�lda bemenethez tartoz� kimenet
1 2 3 5 7 4 9 6 8 10
11 13 17 19 14 15 16 12 18 20
*/
typedef struct szam{
	int ertek;
	int osztok_db;
}szam;
int osztok(int n){
	if(n==1){
		return 1;
	}
	int i,db=0;
	for(i=2; i<=n/2;i++){
		if(n%i==0){
			db++;
		}
	}
	return db+2; 
}
int hasonlit(const void *a, const void*b){
	szam *sz1 = (szam*)a;
	szam *sz2 = (szam*)b;
	int kul = sz1->osztok_db-sz2->osztok_db;
	if(kul==0)
		return sz1->ertek-sz2->ertek;
	else
		return kul;
}
int main(){
	int n;
	while(scanf("%d",&n)!=EOF){
		szam szamok[n];
		int i;
		for(i=0; i<n;i++){
			int m;
			scanf("%d",&m);
			szamok[i].osztok_db=osztok(m);
			szamok[i].ertek=m;
		}
		qsort(szamok,n,sizeof(szam),hasonlit);
		for(i=0; i<n;i++){
			if(i!=n-1){
				printf("%d ",szamok[i].ertek);
			}
			else{
				printf("%d\n",szamok[i].ertek);
			}		
		}
	}	
	return 0;
}



