#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
�rjon f�ggv�nyt, amely param�terk�nt megkap egy sztringet �s egy n eg�sz sz�mot,
�s � a sztring megv�ltoztat�sa n�lk�l � visszaad egy olyan �j sztringet,
amely �gy �ll el�, hogy a param�terk�nt megkapott sztring minden n. poz�ci�j�ra 
besz�rja az n sz�mjegyet.
P�lda:
vadkacsa 3 
Kimenet:
vad3kac3sa

*/
char *beszur(char *s, int n){
	int h = strlen(s)+strlen(s)/n+1;	
	char *uj = (char *)malloc(sizeof(char)* h);
	int i,v = 0;
	for(i=0; i<strlen(s);i++){
		if((i+1)%n==0){
			uj[v++]=s[i];
			uj[v++]=n+48;
		}
		else{
			uj[v++]=s[i];
		}
	}	
	uj[v++]='\0';
	return uj;
}

int main(){
	
	char s[20];	
	int n;
	scanf("%s %d",s,&n);
	
	printf("Eredeti: %s\n",s);
	printf("Beszurva: %s",beszur(s,n));
	
	return 0;
}
