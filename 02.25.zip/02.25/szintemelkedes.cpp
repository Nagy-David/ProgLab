#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
100;110;120;130;120;110;100;110;120;130
90;100;110;105;110;110;120;100;110
103;123;190;230;210;250;230;240;103
100;110
110;100
*/

int main(){
	
	char sor[1001];
	
	while(gets(sor)!=NULL){
		int szum = 0;
		char *token = strtok(sor,";");
		char elozo[100] = "";
		
		while(token!=NULL){
			//printf("elozo: %s token: %s\n",elozo,token);
			if(strcmp(elozo,"")!=0 && atoi(elozo) < atoi(token)  ){
				//printf("d: %d\n",atoi(token)-atoi(elozo));
				szum+=(atoi(token)-atoi(elozo));
			}
			
			strcpy(elozo,token);
			token = strtok(NULL,";");
		}
		printf("szum: %d\n",szum);
	}
	
	
	
	return 0;
}

