#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
1;The Outfield;All the Love in the World;3:24
2;A-ha;Take on Me;3:33
3;Cindy Lauper;Girls Just Wanna Have Fun;3:44
4;Stevie Wonder;I Just Call to Say I Love You;4:19
5;Men at Work;Down Under;3:29
6;Al Corley;Square Rooms;3:31
7;Queen;I Want to Break Free;4:15
8;Madonna;La Isla Bonita;3:38
9;Laura Branigan;Gloria;3:47
10;The Flirts;Danger;3:56
11;The Flirts;Danger;4:19
*/
typedef struct cd{
	int sorszam;
	char eloado[31];
	char cim[101];
	int hossz;
}cd; 

char* max_elso_elfordulas(cd tomb[], int meret){
	int i;
	int max = tomb[0].hossz;
	char *max_eloado = (char*)malloc(sizeof(char)*31);
	strcpy(max_eloado,tomb[0].eloado);
	for(i=1; i<meret;i++){
		if(tomb[i].hossz>max){
			max = tomb[i].hossz;
			strcpy(max_eloado,tomb[i].eloado);	
		}
	}
	return max_eloado;
}

char* max_utolso_elfordulas(cd tomb[], int meret){
	int i;
	int max = tomb[0].hossz;
	char *max_eloado = (char*)malloc(sizeof(char)*31);
	strcpy(max_eloado,tomb[0].eloado);
	for(i=1; i<meret;i++){
		if(tomb[i].hossz>=max){
			max = tomb[i].hossz;
			strcpy(max_eloado,tomb[i].eloado);	
		}
	}
	return max_eloado;
}

void max_osszes_elofordulas(cd tomb[], int meret){
	int i;
	int max = tomb[0].hossz;
	for(i=1; i<meret;i++){
		if(tomb[i].hossz>max){
			max = tomb[i].hossz;
		}
	}
	printf("Osszes elofordulas:\n");
	for(i=0; i<meret;i++){
		if(tomb[i].hossz == max){
			printf("%s\n",tomb[i].eloado);
		}
	}
}

int main(){
	
	char sor[140];
	cd tomb[100];
	int db = 0;
	
	while(gets(sor)!=NULL){
		char *token;
		token = strtok(sor,";"); //; ment�n tokeniz�l, �s a token string az els� "szeletet" tartalmazza
		tomb[db].sorszam = atoi(token); 
		token = strtok(NULL,";"); //folytatja a k�vetkez� tokenn�l
		strcpy(tomb[db].eloado,token);
		token = strtok(NULL,";");
		strcpy(tomb[db].cim,token);
		token = strtok(NULL,";");
		
		char *token2 = strtok(token,":");
		int perc = atoi(token2);
		token2 = strtok(NULL,":");
		int mp = atoi(token2);
		
		tomb[db].hossz = perc*60+mp;
	
		db++; 
	}

	printf("Elso elofordulas: %s\n",max_elso_elfordulas(tomb,db));
	printf("Utolso elofordulas: %s\n",max_utolso_elfordulas(tomb,db));
	max_osszes_elofordulas(tomb,db);
	
	return 0;
}




