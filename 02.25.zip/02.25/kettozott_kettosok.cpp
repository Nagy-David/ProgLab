#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//�ccs�, �ddz�, �ggy�, �lly�, �nny�, �ssz�, �tty�, �zzs�. 
int double_double_letters(char * s){
	int i,db=0;	
	if(strlen(s)<3){
		return 0;
	}
	for(i=0; i<strlen(s)-2;i++){
		if(s[i]=='c' && s[i+1]=='c' && s[i+2]=='s'){
			db++;
		} 
		if(s[i]=='z' && s[i+1]=='z' && s[i+2]=='s'){
			db++;
		} 
		if(s[i]=='d' && s[i+1]=='d' && s[i+2]=='z'){
			db++;
		} 
		if(s[i]=='s' && s[i+1]=='s' && s[i+2]=='z'){
			db++;
		} 
		if(s[i]=='g' && s[i+1]=='g' && s[i+2]=='y'){
			db++;
		}
		if(s[i]=='l' && s[i+1]=='l' && s[i+2]=='y'){
			db++;
		} 
		if(s[i]=='n' && s[i+1]=='n' && s[i+2]=='y'){
			db++;
		} 
		if(s[i]=='t' && s[i+1]=='t' && s[i+2]=='y'){
			db++;
		} 	
	}
	return db;
}

int main()
{
  char line[ 200 ];
  int double_double_letters( char * );
  while ( gets( line ) != NULL )
    printf( "%d\n", double_double_letters( line ) );
  return EXIT_SUCCESS;
}
