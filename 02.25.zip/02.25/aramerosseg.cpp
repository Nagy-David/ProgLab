#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
0 kA
5 kA
3000 A
3000 kA
3000 mA
*/
int amper( char *s ){
	
	char *token = strtok(s," ");
	int mennyiseg = atoi(token);
	token = strtok(NULL," ");
	if(strcmp(token,"kA")==0){
		return mennyiseg*1000;
	}
	if(strcmp(token,"mA")==0){
		return mennyiseg/1000;
	}
	else{
		return mennyiseg;
	}
}

int main()
{
  char line[ 1000 ];
  int amper( char * );
  while ( gets( line ) != NULL )
    printf( "%d\n", amper( line ) );
  return EXIT_SUCCESS;
}
