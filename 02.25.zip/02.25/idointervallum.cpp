#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
16.00 - 16.00
16.00 - 17.00
11.23 - 22.45
0.00 - 23.59
*/
int minutes( char *s ){
	int hossz = 0;
	char bal[10];
	char jobb[10];
	
	char *token = strtok(s," - ");
	strcpy(bal,token);
	token = strtok(NULL," - ");
	strcpy(jobb,token);
	
	int ido1 = 0;
	char *token2 = strtok(bal,".");
	ido1 += atoi(token2)*60;
	//printf("%s\n",token2);
	token2 = strtok(NULL,".");
	ido1 += atoi(token2);
	//printf("%s\n",token2);
	
	int ido2 = 0;
	token2 = strtok(jobb,".");
	ido2 += atoi(token2)*60;
	token2 = strtok(NULL,".");
	ido2 += atoi(token2);	
	//printf("ido1: %d\n",ido1);
	//printf("ido2: %d\n",ido2);
	return ido2-ido1;
}

int main()
{
  char line[ 1000 ];
  int minutes( char * );
  while ( gets( line ) != NULL )
    printf( "%d\n", minutes( line ) );
  return EXIT_SUCCESS;
}
